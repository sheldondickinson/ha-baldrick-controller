# Code and asset notices

The author's firmware, tools and interface code are MIT licensed under LICENSE. This does not grant rights to third-party model geometry, PDFs, photographs, screenshots or other supplied assets.

The personal tree/bulb model snapshots and generated representations remain private. SOURCE-PROVENANCE.md describes their origins; redistribution rights have not been established.

The clean public build uses newly generated synthetic demo grids and checkpoints, not the supplied vendor geometry. Its source export includes code/build tools and original demo inputs.

Arduino-ESP32/ESP-IDF and Adafruit dependencies retain their own licences. The release builder copies installed dependency licence/notice files into the installer package where available, records exact dependency versions and supplies upstream source links. Review dependency distribution obligations before publishing a binary release; do not treat this project licence as a replacement for theirs.
