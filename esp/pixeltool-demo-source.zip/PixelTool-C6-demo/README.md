# PixelTool-C6 demo source

A portable GPIO tester and HA PixelTool network destination. Pixels organised. Tea optional.

This clean export uses original synthetic demo grids; it excludes personal/vendor geometry and private history. Follow docs/WEB-FLASH.md for the exact supported board, wiring, fresh-install erase consequences, Wi-Fi setup and OTA updates. It does not support Improv Wi-Fi provisioning.

Install the pinned core/libraries listed in the installer BUILD.json, then run scripts/check.sh. The checked-in generated headers contain demo data. See LICENSE and NOTICE.md.
