window.PixelUI={
 pin(){return document.getElementById('accessPin')?.value||sessionStorage.getItem('pixelPin')||''},
 async config(){const r=await fetch('/api/config',{cache:'no-store'});if(!r.ok)throw Error(await r.text());return r.json()},
 async post(path,values){const r=await fetch(path,{method:'POST',body:new URLSearchParams({...values,pin:this.pin()})});if(!r.ok)throw Error(await r.text());return r},
 auth(enabled){const w=document.getElementById('auth');if(w)w.hidden=!enabled},
 remember(pin){sessionStorage.setItem('pixelPin',pin);const input=document.getElementById('accessPin');if(input)input.value=pin}
};
document.addEventListener('DOMContentLoaded',()=>{
 document.querySelectorAll('nav a').forEach(a=>{if(a.pathname===location.pathname)a.setAttribute('aria-current','page')});
 const pin=document.getElementById('accessPin');if(pin){pin.value=PixelUI.pin();pin.addEventListener('input',()=>sessionStorage.setItem('pixelPin',pin.value))}
 PixelUI.config().then(c=>PixelUI.auth(c.pinEnabled)).catch(()=>{});
});
