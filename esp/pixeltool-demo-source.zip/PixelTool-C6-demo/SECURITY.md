# Security and private data

Keep this device on a trusted local network. Do not expose its web GUI, receiver or OTA service to the internet.

The optional web PIN does not disable receiver/OTA PIN authentication. The private access file and full flash backup contain credentials; retain them outside Git with owner-only permissions. Do not paste them into issues or serial-console screenshots.

The receiver requires a PIN-authenticated lease and filters DDP by its owner IP. This is not cryptographic UDP authentication. Stop external senders before testing, and verify blackout physically. Keep external pixels disconnected during flashing.

Public preparation uses synthetic demo models. Do not redistribute personal/vendor geometry or images without rights, including generated headers and compiled firmware containing them.
