"""Build shared local-only web pages and deterministic gzip headers."""
import gzip
from pathlib import Path
BASE = Path(__file__).resolve().parents[1]
HEADER = '''<header><small>EAST ST LIGHTS</small><h1>Pixel Tool</h1><p class="hint">Pixels organised. Tea optional.</p><nav aria-label="Main navigation"><a href="/">Tools</a><a href="/pusher">Pixel Pusher</a><a href="/config">Config</a></nav></header><div id="auth" class="auth-wrap" hidden><section class="card"><label for="accessPin">Access PIN<input class="auth-input" id="accessPin" type="password" inputmode="numeric" maxlength="6" autocomplete="off"></label><small>PIN protection is enabled. Kept only for this browser session.</small></section></div>'''
def page(text):
    return text.replace('__HEADER__', HEADER)
def array(name, text):
    raw = bytearray(gzip.compress(text.encode(), mtime=0))
    raw[9] = 255  # Normalise the platform-specific gzip OS header byte.
    return [f'static const uint8_t {name}_GZ[] PROGMEM = {{'] + [','.join(map(str,raw[i:i+24]))+',' for i in range(0,len(raw),24)] + ['};']
lines = ['#pragma once', '#include <pgmspace.h>']
for name, file in [('TOOLS','tools.html'),('CONFIG','config.html'),('STYLE','ui.css'),('COMMON','common.js')]:
    lines += array(name, page((BASE/'web'/file).read_text()))
(BASE/'PixelTool/UiPages.h').write_text('\n'.join(lines)+'\n')
