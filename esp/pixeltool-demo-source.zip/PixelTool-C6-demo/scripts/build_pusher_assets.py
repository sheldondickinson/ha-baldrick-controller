"""Build static model data and gzip web assets without changing source xModels."""
import gzip, hashlib, json, xml.etree.ElementTree as ET
from build_ui import page
from pathlib import Path
BASE=Path(__file__).resolve().parents[1]
spec=json.loads((BASE/'checkpoints.json').read_text())
data={k:spec[k] for k in ['version','note','palette']};data['models']=[]
header=['// Generated from supplied checkpoints.json; labels are inferred landmarks.','#pragma once','#include <stdint.h>','struct PaletteColour { uint8_t r, g, b; };','struct Checkpoint { uint16_t node; uint8_t colour; };','struct Model { uint16_t count; const Checkpoint *checkpoints; uint16_t checkpointCount; };','constexpr uint16_t MAX_PIXELS = 500;','constexpr uint8_t MODEL_COUNT = 2;','constexpr PaletteColour PALETTE[] = {']
header += ['{%d,%d,%d},'%tuple(p['rgb']) for p in spec['palette']]+['};']
for source in spec['models']:
 p=BASE/'source_models'/source['file'];root=ET.parse(p).getroot();nodes={}
 for y,row in enumerate(root.attrib['CustomModel'].split(';')):
  for x,token in enumerate(row.split(',')):
   if token.strip():
    n=int(token);assert n not in nodes;nodes[n]=[x,y]
 assert set(nodes)==set(range(1,source['count']+1))
 points=source['checkpoints'];assert points[0][0]==1 and points[-1][0]==source['count']
 assert all(a[0]<b[0] for a,b in zip(points,points[1:]))
 m={k:v for k,v in source.items() if k!='checkpoints'}
 m.update(coords=[nodes[n] for n in range(1,source['count']+1)],sourceSHA256=hashlib.sha256(p.read_bytes()).hexdigest(),sourceStrings={k:v for k,v in root.attrib.items() if k=='CustomStrings' or k.startswith('String') and k[6:].isdigit()},checkpoints=[])
 header.append('constexpr Checkpoint '+source['id'].upper()+'_CHECKPOINTS[] = {')
 for i,(n,kind,label) in enumerate(points):
  end=points[i+1][0]-1 if i+1<len(points) else m['count']
  m['checkpoints'].append(dict(id=f"{m['prefix']}{i+1:02}",node=n,end=end,kind=kind,label=label,colour=i%len(spec['palette'])))
  header.append('{%d,%d},'%(n,i%len(spec['palette'])))
 header.append('};');data['models'].append(m)
header.append('constexpr Model MODELS[] = {')
header += ['{%d,%s_CHECKPOINTS,%d},'%(m['count'],m['id'].upper(),len(m['checkpoints'])) for m in data['models']]+['};']
(BASE/'PixelTool/ModelData.h').write_text('\n'.join(header)+'\n')
(BASE/'model-data.json').write_text(json.dumps(data,indent=2)+'\n')
ui=(BASE/'web/interface.html').read_text().replace('__MODEL_DATA__',json.dumps(data,separators=(',',':'))).replace('__COLOUR_JS__',(BASE/'web/colour.js').read_text())
ui=page(ui)
assert '__MODEL_DATA__' not in ui
(BASE/'web/pusher.html').write_text(ui)
raw=bytearray(gzip.compress(ui.encode(),mtime=0))
raw[9]=255  # Deterministic gzip header across Python/macOS/Linux.
lines=['#pragma once','#include <pgmspace.h>','static const uint8_t PUSHER_PAGE_GZ[] PROGMEM = {']
lines += [','.join(map(str,raw[i:i+24]))+',' for i in range(0,len(raw),24)]+['};']
(BASE/'PixelTool/PusherPage.h').write_text('\n'.join(lines)+'\n')
print('Validated: tree 500 nodes / 45 checkpoints; bulb 350 nodes / 31 checkpoints; gzip UI',len(raw),'bytes')
