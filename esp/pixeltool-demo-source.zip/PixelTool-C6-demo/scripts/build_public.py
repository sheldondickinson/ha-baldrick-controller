#!/usr/bin/env python3
"""Build a demo-only source/ESP Web Tools bundle without changing personal assets."""

import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
import urllib.request
import zipfile
from pathlib import Path

BASE = Path(__file__).resolve().parents[1]
VERSION = "0.2.1"
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--output", type=Path, default=BASE / "release-dist" / VERSION)
parser.add_argument(
    "--arduino-cli",
    default=os.environ.get(
        "ARDUINO_CLI",
        "/Applications/Arduino IDE.app/Contents/Resources/app/lib/backend/resources/arduino-cli",
    ),
)
parser.add_argument(
    "--deny-file",
    type=Path,
    help="Private JSON list of identifiers to reject; never included in output",
)
args = parser.parse_args()
if args.output.exists():
    parser.error(
        "Output already exists; choose a new directory rather than overwriting a release"
    )
with tempfile.TemporaryDirectory(prefix="pixeltool-public-") as temporary:
    root = Path(temporary)
    source = root / "source"
    source.mkdir()
    files = {
        "PixelTool": (
            "PixelTool.ino",
            "DeviceConfig.h",
            "PixelLogic.h",
            "PusherCore.h",
            "DdpReceiver.h",
        ),
        "web": (
            "tools.html",
            "config.html",
            "ui.css",
            "common.js",
            "interface.html",
            "colour.js",
        ),
    }
    for directory, names in files.items():
        (source / directory).mkdir()
        for name in names:
            shutil.copy2(BASE / directory / name, source / directory / name)
    for directory in ("scripts", "tests", "source_models", "docs"):
        (source / directory).mkdir()
    for name in (
        "build_ui.py",
        "build_pusher_assets.py",
        "check.sh",
        "device.py",
        "ota_update.py",
        "build_public.py",
    ):
        shutil.copy2(BASE / "scripts" / name, source / "scripts" / name)
    for name in (
        "test_logic.cpp",
        "test_config.cpp",
        "test_pusher_adapter.cpp",
        "test_ddp_receiver.cpp",
        "test_pusher_colours.py",
    ):
        shutil.copy2(BASE / "tests" / name, source / "tests" / name)
    for name in (
        "LICENSE",
        "NOTICE.md",
        "requirements-tools.txt",
        ".gitignore",
        "SECURITY.md",
        "CHANGELOG.md",
    ):
        shutil.copy2(BASE / name, source / name)
    shutil.copy2(BASE / "docs/WEB-FLASH.md", source / "docs/WEB-FLASH.md")
    (source / "installer").mkdir()
    shutil.copy2(BASE / "installer/index.html", source / "installer/index.html")
    spec = {
        "version": VERSION,
        "note": "Original synthetic demo grids. Checkpoints demonstrate the UI, not verified physical turns.",
        "palette": json.loads((BASE / "checkpoints.json").read_text())["palette"],
        "models": [],
    }
    for identity, count, checkpoints, prefix in (
        ("tree", 500, 45, "A"),
        ("bulb", 350, 31, "B"),
    ):
        rows = []
        for row in range(count // 10):
            numbers = list(range(row * 10 + 1, row * 10 + 11))
            if row % 2:
                numbers.reverse()
            rows.append(",".join(map(str, numbers)))
        filename = "Demo-Grid-" + str(count) + ".xmodel"
        (source / "source_models" / filename).write_text(
            '<custommodel name="Demo Grid '
            + str(count)
            + '" DisplayAs="Custom" StringType="RGB Nodes" CustomModel="'
            + ";".join(rows)
            + '"/>'
        )
        points = [
            [
                1 + i * (count - 1) // (checkpoints - 1),
                "demo",
                "Demo section " + str(i + 1),
            ]
            for i in range(checkpoints)
        ]
        spec["models"].append(
            {
                "id": identity,
                "title": "Demo Grid " + str(count),
                "file": filename,
                "count": count,
                "prefix": prefix,
                "displayXScale": 1,
                "checkpoints": points,
            }
        )
    (source / "checkpoints.json").write_text(json.dumps(spec, indent=2) + "\n")
    sketch = source / "PixelTool/PixelTool.ino"
    text = (
        sketch.read_text()
        .replace("GE Singing Tree", "Demo Grid 500")
        .replace("GE Upright Bulb R3", "Demo Grid 350")
        .replace("SINGING TREE", "DEMO GRID 500")
        .replace("UPRIGHT BULB", "DEMO GRID 350")
    )
    sketch.write_text(text)
    interface = source / "web/interface.html"
    text = (
        interface.read_text()
        .replace("Tree and Bulb Pusher", "Demo Model Pusher")
        .replace(
            "Tree second string only: first node = 301, if its first physical pixel really corresponds to model node 301.",
            "Use a verified first-node offset for a partially connected prop.",
        )
    )
    interface.write_text(text)
    subprocess.run(
        [sys.executable, str(source / "scripts/build_pusher_assets.py")], check=True
    )
    # Positive allowlist + generated demo profile, with optional private deny values.
    # The deny file is external so the validator itself cannot leak owner identifiers.
    deny = json.loads(args.deny_file.read_text()) if args.deny_file else []
    if not isinstance(deny, list) or any(
        not isinstance(value, str) or not value for value in deny
    ):
        raise ValueError("Deny file must contain a list of non-empty strings")
    generated = json.loads((source / "model-data.json").read_text())
    if any(
        not model["title"].startswith("Demo Grid ")
        or not model["file"].startswith("Demo-Grid-")
        for model in generated["models"]
    ):
        raise RuntimeError("Export contains a non-demo model profile")
    for path in source.rglob("*"):
        if path.suffix in (".py", ".json", ".html", ".ino", ".h", ".md", ".xmodel"):
            content = path.read_text()
            if any(value in content for value in deny):
                raise RuntimeError(
                    "Private reference survived export: "
                    + str(path.relative_to(source))
                )
    adapter = source / "tests/test_pusher_adapter.cpp"
    text = adapter.read_text().replace(
        "assert(c.r == 32 && c.g == 32 && c.b == 0); // T24, model node 301, yellow",
        "s.enabled = true;\n  auto expected = Pusher::colourAt(s, 301, false);\n  assert(c.r == expected.r && c.g == expected.g && c.b == expected.b);",
    )
    text = text.replace(
        "assert(c.r == 32 && c.g == 32 && c.b == 0); // T45, model node 500",
        "expected = Pusher::colourAt(s, 500, false);\n  assert(c.r == expected.r && c.g == expected.g && c.b == expected.b);",
    )
    adapter.write_text(text)
    formatter = (
        os.environ.get("CLANG_FORMAT")
        or shutil.which("clang-format")
        or "/Applications/Arduino IDE.app/Contents/Resources/app/lib/backend/resources/clang-format"
    )
    subprocess.run([formatter, "-i", str(adapter)], check=True)
    build = root / "build"
    subprocess.run(
        [
            args.arduino_cli,
            "compile",
            "--fqbn",
            "esp32:esp32:esp32c6:CDCOnBoot=cdc,FlashSize=8M",
            "--warnings",
            "all",
            "--build-path",
            str(build),
            str(source / "PixelTool"),
        ],
        check=True,
    )
    site = root / "installer"
    site.mkdir()
    shutil.copy2(BASE / "installer/index.html", site / "index.html")
    firmware = site / "firmware"
    firmware.mkdir()
    subprocess.run(
        [
            sys.executable,
            "-m",
            "esptool",
            "--chip",
            "esp32c6",
            "merge_bin",
            "--flash_mode",
            "dio",
            "--flash_freq",
            "80m",
            "--flash_size",
            "8MB",
            "-o",
            str(firmware / "pixeltool-demo-merged.bin"),
            "0x0",
            str(build / "PixelTool.ino.bootloader.bin"),
            "0x8000",
            str(build / "PixelTool.ino.partitions.bin"),
            "0xe000",
            str(build / "boot_app0.bin"),
            "0x10000",
            str(build / "PixelTool.ino.bin"),
        ],
        check=True,
    )
    manifest = {
        "name": "PixelTool demo (verified C6 8 MiB profile)",
        "version": VERSION,
        "new_install_prompt_erase": True,
        "new_install_improv_wait_time": 0,
        "builds": [
            {
                "chipFamily": "ESP32-C6",
                "parts": [{"path": "firmware/pixeltool-demo-merged.bin", "offset": 0}],
            }
        ],
    }
    (site / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    shutil.copy2(build / "PixelTool.ino.bin", firmware / "pixeltool-demo-ota.bin")
    notices = site / "third-party-notices"
    notices.mkdir()
    for setting, pattern in (
        ("directories.user", "libraries/Adafruit*/*"),
        ("directories.data", "packages/esp32/hardware/esp32/3.3.12/*"),
    ):
        directory = Path(
            subprocess.check_output(
                [args.arduino_cli, "config", "get", setting], text=True
            ).strip()
        )
        for file in directory.glob(pattern):
            if file.is_file() and any(
                word in file.name.lower()
                for word in ("license", "licence", "notice", "copying")
            ):
                shutil.copy2(file, notices / (file.parent.name + "-" + file.name))
    core_license = urllib.request.urlopen(
        "https://raw.githubusercontent.com/espressif/arduino-esp32/3.3.12/LICENSE.md",
        timeout=15,
    ).read()
    (notices / "Arduino-ESP32-3.3.12-LICENSE.md").write_bytes(core_license)
    (notices / "UPSTREAM-SOURCES.md").write_text(
        "# Upstream dependency sources\n\nPinned build dependencies remain under their upstream licences.\n\n- Arduino-ESP32 3.3.12: https://github.com/espressif/arduino-esp32/tree/3.3.12\n- ESP-IDF: https://github.com/espressif/esp-idf (version supplied by the pinned Arduino core)\n- Adafruit NeoPixel 1.15.5: https://github.com/adafruit/Adafruit_NeoPixel/tree/1.15.5\n- Adafruit GFX 1.12.6: https://github.com/adafruit/Adafruit-GFX-Library/tree/1.12.6\n- Adafruit BusIO 1.17.4: https://github.com/adafruit/Adafruit_BusIO/tree/1.17.4\n- Adafruit ST7735/ST7789 1.11.0: https://github.com/adafruit/Adafruit-ST7735-Library/tree/1.11.0\n\nThe accompanying demo source can be rebuilt with these dependencies; review their distribution terms before publication.\n"
    )
    (site / "BUILD.json").write_text(
        json.dumps(
            {
                "version": VERSION,
                "profile": "demo",
                "board": "Waveshare ESP32-C6-LCD-1.47-M, verified 8 MiB profile",
                "core": "esp32 3.3.12",
                "libraries": {
                    "Adafruit NeoPixel": "1.15.5",
                    "Adafruit GFX Library": "1.12.6",
                    "Adafruit BusIO": "1.17.4",
                    "Adafruit ST7735 and ST7789 Library": "1.11.0",
                },
                "source_profile": "Original synthetic demo grids; no personal/vendor model geometry",
            },
            indent=2,
        )
        + "\n"
    )
    (source / "README.md").write_text(
        "# PixelTool-C6 demo source\n\nA portable GPIO tester and HA PixelTool network destination. Pixels organised. Tea optional.\n\nThis clean export uses original synthetic demo grids; it excludes personal/vendor geometry and private history. Follow docs/WEB-FLASH.md for the exact supported board, wiring, fresh-install erase consequences, Wi-Fi setup and OTA updates. It does not support Improv Wi-Fi provisioning.\n\nInstall the pinned core/libraries listed in the installer BUILD.json, then run scripts/check.sh. The checked-in generated headers contain demo data. See LICENSE and NOTICE.md.\n"
    )
    hashes = []
    for file in sorted(site.rglob("*")):
        if file.is_file():
            hashes.append(
                hashlib.sha256(file.read_bytes()).hexdigest()
                + "  "
                + str(file.relative_to(site))
            )
    (site / "SHA256SUMS").write_text("\n".join(hashes) + "\n")
    args.output.mkdir(parents=True)
    shutil.copytree(site, args.output / "installer")
    with zipfile.ZipFile(
        args.output / "pixeltool-demo-source.zip", "x", compression=zipfile.ZIP_DEFLATED
    ) as archive:
        for file in source.rglob("*"):
            if file.is_file() and "__pycache__" not in str(file):
                archive.write(
                    file, "PixelTool-C6-demo/" + str(file.relative_to(source))
                )
    print("Prepared clean demo installer and source at", args.output)
