#!/usr/bin/env python3
"""Authenticated OTA using a private access file, without secrets in argv."""

import argparse
import importlib.util
import ipaddress
import json
import socket
import stat
import urllib.request
from pathlib import Path

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--host", required=True)
parser.add_argument("--id", required=True, help="Verified MAC identity without colons")
parser.add_argument("--access-file", type=Path, required=True)
parser.add_argument("--binary", type=Path, required=True)
parser.add_argument(
    "--sdk",
    type=Path,
    default=Path.home()
    / "Library/Arduino15/packages/esp32/hardware/esp32/3.3.12/tools/espota.py",
)
a = parser.parse_args()
if not ipaddress.ip_address(a.host).is_private:
    parser.error("OTA target must be on the private local network")
if stat.S_IMODE(a.access_file.stat().st_mode) & 0o077:
    parser.error("Private access file must have owner-only permissions")
info = json.load(
    urllib.request.urlopen("http://" + a.host + "/api/receiver", timeout=5)
)
if (
    info["id"] != a.id
    or info["owned"]
    or info["standalone_active"]
    or info["stream_active"]
):
    parser.error("Wrong device or pixel output is not stopped")
if not 0 < a.binary.stat().st_size <= 1310720:
    parser.error("Binary does not fit the verified app partition")
pin = json.loads(a.access_file.read_text())["pin"]
# Avoid any accidental debug logging from the SDK helper.
import logging

logging.getLogger().setLevel(logging.WARNING)
spec = importlib.util.spec_from_file_location("espota", a.sdk)
ota = importlib.util.module_from_spec(spec)
spec.loader.exec_module(ota)
ota.PROGRESS = True
ota.TIMEOUT = 15
with socket.socket() as probe:
    probe.bind(("0.0.0.0", 0))
    local_port = probe.getsockname()[1]
result = ota.serve(
    a.host, "0.0.0.0", 3232, local_port, pin, False, str(a.binary), ota.FLASH
)
raise SystemExit(result)
