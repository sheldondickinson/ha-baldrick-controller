#!/usr/bin/env bash
set -euo pipefail
project_root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
output_dir="${PIXELTOOL_CHECK_DIR:-$project_root/verification}"
build_dir="${PIXELTOOL_BUILD_DIR:-$project_root/build}"
ide_tools='/Applications/Arduino IDE.app/Contents/Resources/app/lib/backend/resources'
cli="${ARDUINO_CLI:-$ide_tools/arduino-cli}"
formatter="${CLANG_FORMAT:-$ide_tools/clang-format}"
if [[ ! -x "$cli" ]]; then cli="${ARDUINO_CLI:-arduino-cli}"; fi
if [[ ! -x "$formatter" ]]; then formatter="${CLANG_FORMAT:-clang-format}"; fi
mkdir -p "$output_dir"
"$formatter" --dry-run --Werror "$project_root/PixelTool/PixelTool.ino" "$project_root/PixelTool/PixelLogic.h" "$project_root/tests/test_logic.cpp"
clang++ -std=c++17 -Wall -Wextra -Werror -fsanitize=address,undefined "$project_root/tests/test_logic.cpp" -o "$output_dir/test_logic"
"$output_dir/test_logic"
"$formatter" --dry-run --Werror "$project_root/PixelTool/DeviceConfig.h" "$project_root/tests/test_config.cpp"
clang++ -std=c++17 -Wall -Wextra -Werror -fsanitize=address,undefined "$project_root/tests/test_config.cpp" -o "$output_dir/test_config"
"$output_dir/test_config"
"$formatter" --dry-run --Werror "$project_root/PixelTool/DdpReceiver.h" "$project_root/tests/test_ddp_receiver.cpp"
clang++ -std=c++17 -Wall -Wextra -Werror -fsanitize=address,undefined "$project_root/tests/test_ddp_receiver.cpp" -o "$output_dir/test_ddp_receiver"
"$output_dir/test_ddp_receiver"
node --check "$project_root/web/common.js"
python3 - "$project_root" "$output_dir" <<'PYJS'
import re, sys, subprocess
from pathlib import Path
for page in ['tools.html', 'config.html', 'pusher.html']:
 source=(Path(sys.argv[1])/'web'/page).read_text()
 for i, js in enumerate(re.findall(r'<script>([\s\S]*?)</script>',source)):
  target=Path(sys.argv[2])/f'{page}-{i}.js'
  target.write_text(js)
  subprocess.run(['node', '--check', str(target)], check=True)
PYJS
"$formatter" --dry-run --Werror "$project_root/PixelTool/PusherCore.h" "$project_root/tests/test_pusher_adapter.cpp"
clang++ -std=c++17 -Wall -Wextra -Werror -fsanitize=address,undefined "$project_root/tests/test_pusher_adapter.cpp" -o "$output_dir/test_pusher_adapter"
"$output_dir/test_pusher_adapter"
python3 "$project_root/tests/test_pusher_colours.py"
node --check "$project_root/web/colour.js"
python3 - "$project_root" "$output_dir" <<'PY2'
import re, sys
from pathlib import Path
source=(Path(sys.argv[1])/'web/pusher.html').read_text()
for i, js in enumerate(re.findall(r'<script>([\s\S]*?)</script>',source)):
 (Path(sys.argv[2])/f'pusher-{i}.js').write_text(js)
PY2
node --check "$output_dir/pusher-1.js"
"$cli" compile --fqbn esp32:esp32:esp32c6:CDCOnBoot=cdc,FlashSize=8M --warnings all --build-path "$build_dir" "$project_root/PixelTool"
