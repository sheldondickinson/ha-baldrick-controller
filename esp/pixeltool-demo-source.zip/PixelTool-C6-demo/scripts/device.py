#!/usr/bin/env python3
"""Local USB diagnostics. Private ACCESS data is never printed."""
import argparse
import json
import os
import time
from pathlib import Path

import serial

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('command', type=str.upper, choices=['STATUS', 'ACCESS', 'WIFI', 'JOIN', 'REBOOT'])
parser.add_argument('--port', default=os.environ.get('PIXELTOOL_PORT', '/dev/cu.usbmodem1101'))
parser.add_argument('--output-dir', type=Path, default=Path(__file__).resolve().parents[1] / 'verification')
args = parser.parse_args()
command = args.command
args.output_dir.mkdir(parents=True, exist_ok=True)
if command == 'WIFI':
    import sys
    wifi = json.load(sys.stdin)
    ssid, password = wifi['ssid'], wifi['password']
    if any(c in ssid + password for c in '\r\n\t'):
        parser.error('Wi-Fi details cannot contain tabs or line breaks')
    if not 1 <= len(ssid.encode()) <= 32 or len(password.encode()) > 63 or (password and len(password.encode()) < 8):
        parser.error('SSID must be 1–32 bytes; password must be empty or 8–63 bytes')
    wire = 'WIFI\t' + ssid + '\t' + password
else:
    wire = command
received = False
with serial.Serial(args.port, 115200, timeout=0.3) as port:
    time.sleep(0.4)
    port.reset_input_buffer()
    port.write((wire + '\n').encode())
    finish = time.monotonic() + (15 if command == 'WIFI' else 5)
    while time.monotonic() < finish:
        line = port.readline().decode(errors='replace').strip()
        if not line:
            continue
        if command == 'ACCESS' and line.startswith('{'):
            data = json.loads(line)
            if 'pin' in data:
                target = args.output_dir / '.device-access.json'
                fd = os.open(target, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
                os.fchmod(fd, 0o600)
                with os.fdopen(fd, 'w') as file:
                    json.dump(data, file)
                print(f'Private access details saved to {target}; not printed.')
                received = True
                break
        elif command == 'STATUS' and line.startswith('{'):
            data = json.loads(line)
            print(json.dumps(data))
            (args.output_dir / 'last-status.json').write_text(json.dumps(data, indent=2) + '\n')
            received = True
            break
        elif command in ('WIFI', 'JOIN') and line.startswith(command):
            print(line)
            received = True
            break
        elif command == 'REBOOT':
            print(line)
            received = True
if not received and command != 'REBOOT':
    raise SystemExit('No matching reply received; check the selected port and device firmware.')
