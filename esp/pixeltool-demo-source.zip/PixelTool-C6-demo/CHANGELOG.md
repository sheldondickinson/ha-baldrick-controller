# Changelog

## 0.2.1 beta — 08/10/2026

- Browser flashing/first-setup guide and demo-only ESP Web Tools package builder.
- Clean source export with original synthetic models and dependency notices.
- Firmware CI, deterministic gzip headers and pinned formatting.
- Original light-touch GUI/idle-footer copy; critical controls remain explicit.

## 0.2.0 beta — 07/10/2026

- Private leased DDP receiver for HA PixelTool, complete-frame validation and sender filtering.
- Two-second missing-frame blackout/release and explicit standalone emergency stop.
- Retained OTA PIN and private OTA helper; compatible-profile wireless updates tested.
- Standalone GUI, settings, GPIO configuration and personal model profile retained.

The demo package is a separate model profile. Existing vendor assets and private history are not cleared for public redistribution.
