#include "../PixelTool/PixelLogic.h"
#include <cassert>
#include <cstdio>
using namespace pixeltool;
int main() {
  Model m;
  assert(parseEnds("47,82;117", m, 500));
  assert(m.used == 3 && expected(m, 0) == 47 && expected(m, 2) == 117 &&
         expected(m, 3) == 500);
  assert(!parseEnds("47,47", m, 500));
  assert(!parseEnds("501", m, 500));
  assert(!parseEnds("50oops", m, 500));
  assert(parseEnds("", m, 500) && m.used == 0);
  assert(cutTotal(125, 4, 20) == 520 && cutTotal(500, 3, 0) == -1);
  auto c = [&](int number) {
    return colour(number - 1, 1, 1, 1, 1, 125, 4, 20, m, 40, 75, 0);
  };
  assert(c(124).r == 40 && c(124).g == 40);
  assert(c(125).b == 75 && c(126).b == 75);
  assert(c(500).b == 75 &&
         c(501).b == 75); // virtual boundary between strand and tail
  assert(c(502).r == 40 && c(502).b == 40);
  assert(c(520).r == 75 && c(520).g == 0);
  assert(c(521).r == 75 && c(521).g == 0);
  assert(c(522).r == 0 && c(522).b == 0);
  assert(parseEnds("47,82,117", m, 500));
  auto guide = [&](int number) {
    return colour(number - 1, 2, 104, 1, 1, 125, 4, 20, m, 40, 75, 0);
  };
  assert(guide(117).r == 75 && guide(117).b == 0);
  assert(guide(118).b == 75 && guide(118).r == 0);
  assert(guide(104).r == 75 && guide(104).g == 75);

  // The implicit final end must be checked, even with no intermediate ends.
  assert(markDifference(m, 3, 499) == -1);
  assert(markDifference(m, 3, 500) == 0);
  assert(markDifference(m, 0, 48) == 1);
  assert(guide(500).r == 75 && guide(500).g == 0);
  assert(parseEnds("", m, 1));
  assert(markDifference(m, 0, 1) == 0);
  assert(colour(0, 2, 1, 1, 1, 125, 4, 20, m, 40, 75, 0).r == 75);
  assert(cutTotal(2147483647, 2147483647, 2147483647) == -1);
  assert(cutTotal(1000, 1, 0) == 1000);
  assert(cutTotal(0, 1, 0) == -1);
  Model before = m;
  assert(!parseEnds("2,1", m, 5));
  assert(m.count == before.count && m.used == before.used);
  assert(!parseEnds("9999999999999999999999", m, 1000));
  assert(!parseEnds("-1", m, 1000));
  assert(!parseEnds("1", m, 0));
  assert(!parseEnds("1", m, 1001));
  assert(parseEnds("47,82,117", m, 1000));
  // Every mode and rainbow phase honours the channel cap and array bounds.
  for (int mode = 0; mode < 13; ++mode)
    for (int i = -1; i <= 1000; ++i) {
      auto pixel = colour(i, mode, 48, 10, 20, 125, 4, 20, m, 76, 76, 12345);
      assert(pixel.r <= 76 && pixel.g <= 76 && pixel.b <= 76);
      if (i < 0 || i == 1000)
        assert(pixel.r == 0 && pixel.g == 0 && pixel.b == 0);
    }
  for (int hue = 0; hue < 256; ++hue) {
    auto pixel = rainbow(hue, 76);
    assert(pixel.r <= 76 && pixel.g <= 76 && pixel.b <= 76);
  }
  assert(rainbow(0, 76).r == 76);
  assert(rainbow(85, 76).g == 76);
  assert(rainbow(170, 76).b == 76);
  assert(colour(999, 1, 1, 1, 1, 1000, 1, 0, m, 40, 75, 0).r == 75);
  assert(colour(10, 5, 1, 10, 20, 125, 4, 0, m, 40, 75, 0).g == 40);
  assert(colour(20, 5, 1, 10, 20, 125, 4, 0, m, 40, 75, 0).g == 0);
  assert(colour(0, 11, 1, 1, 1, 125, 4, 0, m, 40, 75, 0).r == 40);
  assert(colour(0, 12, 1, 1, 1, 125, 4, 0, m, 40, 75, 0).r == 40);
  puts("PASS: cutter, guide including final end, parsing, bounds, rainbow and "
       "brightness caps");
}
