#include "../PixelTool/DdpReceiver.h"
#include <assert.h>
#include <vector>
std::vector<uint8_t> packet(size_t offset, size_t length, bool push) {
  std::vector<uint8_t> p(10 + length, 12);
  p[0] = push ? 0x41 : 0x40;
  p[1] = 1;
  p[2] = 0;
  p[3] = 1;
  p[4] = (offset >> 24) & 255;
  p[5] = (offset >> 16) & 255;
  p[6] = (offset >> 8) & 255;
  p[7] = offset & 255;
  p[8] = (length >> 8) & 255;
  p[9] = length & 255;
  return p;
}
int main() {
  assert(!Ddp::expired(100, 101, 2000));
  assert(Ddp::expired(3100, 100, 2000));
  assert(!Ddp::expired(10, UINT32_MAX - 10, 2000));
  Ddp::Receiver r;
  r.begin(1000);
  auto a = packet(0, 1440, false), b = packet(1440, 1440, false),
       c = packet(2880, 120, true);
  assert(r.packet(a.data(), a.size()) == Ddp::Result::Partial);
  assert(r.packet(c.data(), c.size()) == Ddp::Result::Invalid);
  assert(r.pixels[0] == 0); // Lost fragment never commits incomplete frame.
  assert(r.packet(a.data(), a.size()) == Ddp::Result::Partial);
  assert(r.packet(b.data(), b.size()) == Ddp::Result::Partial);
  assert(r.packet(c.data(), c.size()) == Ddp::Result::Complete);
  assert(r.pixels[2999] == 12);
  c[7] = 255;
  assert(r.packet(c.data(), c.size()) == Ddp::Result::Invalid);
  a[3] = 2;
  assert(r.packet(a.data(), a.size()) == Ddp::Result::Invalid);
  r.begin(50);
  auto d = packet(0, 150, true);
  assert(r.packet(d.data(), d.size()) == Ddp::Result::Complete);
  r.begin(1001);
  assert(r.packet(d.data(), d.size()) == Ddp::Result::Invalid);
}
