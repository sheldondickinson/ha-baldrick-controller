#include "../PixelTool/PusherCore.h"
#include <cassert>
#include <cstdio>
#include <initializer_list>
int main() {
  Pusher::State s;
  s.first = 301;
  auto c = Pusher::physicalColour(s, 0, 38, true, false);
  s.enabled = true;
  auto expected = Pusher::colourAt(s, 301, false);
  assert(c.r == expected.r && c.g == expected.g && c.b == expected.b);
  c = Pusher::physicalColour(s, 199, 38, true, false);
  expected = Pusher::colourAt(s, 500, false);
  assert(c.r == expected.r && c.g == expected.g && c.b == expected.b);
  c = Pusher::physicalColour(s, 200, 38, true, false);
  assert(c.r == 0 && c.g == 0 && c.b == 0);
  for (int model = 0; model < 2; ++model)
    for (int mode = 0; mode < 7; ++mode)
      for (int cap : {1, 12, 38, 64, 76})
        for (int index = -1; index <= 1000; ++index) {
          s = Pusher::State{};
          s.model = model;
          s.mode = mode;
          s.level = 64;
          auto p = Pusher::physicalColour(s, index, cap, true, true);
          assert(p.r <= cap && p.g <= cap && p.b <= cap);
          assert(p.r <= 64 && p.g <= 64 && p.b <= 64);
          if (index < 0 || index >= MODELS[model].count)
            assert(!p.r && !p.g && !p.b);
          p = Pusher::physicalColour(s, index, cap, false, true);
          assert(!p.r && !p.g && !p.b);
        }
  puts("PASS: physical offset 301, black tail to 1000, dual brightness caps, "
       "disarmed frames");
}
