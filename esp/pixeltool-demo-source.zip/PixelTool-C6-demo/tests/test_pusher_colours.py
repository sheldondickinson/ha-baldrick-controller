"""Cross-check every output pixel in C++ firmware logic and JavaScript preview.
Runs on the host, not on an ESP. Requires g++ and Node.js.
"""
import json
from pathlib import Path
import subprocess
import tempfile

BASE = Path(__file__).resolve().parents[1]
DATA = json.loads((BASE / "model-data.json").read_text())
scenarios = []
for mi, model in enumerate(DATA["models"]):
    base = dict(model=mi, mode=0, run=0, node=1, level=32, first=1, order=0, enabled=True)
    for mode in range(7):
        for level in (1, 32, 64):
            for pulse in (False, True):
                scenarios.append(dict(base, mode=mode, level=level, pulse=pulse))
    for k, cp in enumerate(model["checkpoints"]):
        for pulse in (False, True):
            scenarios.append(dict(base, mode=2, run=k, node=cp["node"], pulse=pulse))
            scenarios.append(dict(base, mode=3, run=k, node=cp["node"], pulse=pulse))
    for first in (2, model["count"] // 2, model["count"]):
        scenarios.append(dict(base, first=first, pulse=True))
    scenarios.append(dict(base, first=301 if mi == 0 else 201, pulse=True))
    scenarios.append(dict(base, enabled=False, pulse=True))

CPP = r'''
#include <iostream>
#include "PusherCore.h"
int main() {
  int model, mode, run, node, level, first, order, enabled, pulse;
  while (std::cin >> model >> mode >> run >> node >> level >> first >> order >> enabled >> pulse) {
    Pusher::State s;
    s.model=model; s.mode=mode; s.run=run; s.node=node; s.level=level;
    s.first=first; s.order=order; s.enabled=enabled;
    if (!Pusher::valid(s)) return 3;
    Pusher::RGB frame[MAX_PIXELS]; Pusher::makeFrame(s,pulse,frame);
    for (unsigned i=0; i<MAX_PIXELS; ++i) {
      const auto &p=frame[i];
      std::cout << ((uint32_t(p.r)<<16)|(uint32_t(p.g)<<8)|p.b) << (i+1==MAX_PIXELS?'\n':' ');
    }
  }
  Pusher::State bad; bad.model=99;
  if (Pusher::valid(bad)) return 4;
  bad=Pusher::State{}; bad.first=0;
  if (Pusher::valid(bad)) return 5;
  return 0;
}
'''

with tempfile.TemporaryDirectory(prefix="pixel-pusher-test-") as temp:
    root = Path(temp)
    src, binary = root / "test.cpp", root / "test"
    src.write_text(CPP)
    subprocess.run(["g++", "-std=c++11", "-Wall", "-Wextra", "-Werror", "-I", str(BASE / "PixelTool"), str(src), "-o", str(binary)], check=True)
    fields = ("model", "mode", "run", "node", "level", "first", "order", "enabled", "pulse")
    lines = "\n".join(" ".join(str(int(s[f])) for f in fields) for s in scenarios) + "\n"
    actual = subprocess.check_output([str(binary)], input=lines, text=True).splitlines()
    script = r'''
const fs=require('fs');
const {pixelRGB}=require(process.argv[1]);
const input=JSON.parse(fs.readFileSync(0,'utf8'));
const out=input.scenarios.map(s=>Array.from({length:500},(_,i)=>{
  const [r,g,b]=pixelRGB(input.data,s,s.first+i,s.pulse);return (r<<16)|(g<<8)|b;
}));process.stdout.write(JSON.stringify(out));
'''
    expected = json.loads(subprocess.check_output(["node", "-e", script, str(BASE / "web/colour.js")], input=json.dumps(dict(data=DATA, scenarios=scenarios)), text=True))
    assert len(actual) == len(expected) == len(scenarios)
    for case, (line, wanted) in enumerate(zip(actual, expected)):
        got = list(map(int, line.split()))
        assert got == wanted, f"Colour mismatch in scenario {case}: {scenarios[case]}"
        s = scenarios[case]
        count = DATA["models"][s["model"]]["count"] - s["first"] + 1
        assert all(v == 0 for v in got[count:]), "Unused tail not cleared"
        if not s["enabled"]:
            assert all(v == 0 for v in got), "Disabled output not black"
        else:
            assert all(v != 0 for v in got[:count]), "A selected in-range pixel is dark"
        assert all(max(v >> 16, (v >> 8) & 255, v & 255) <= 64 for v in got)

print(f"PASS: {len(scenarios)} scenarios, {len(scenarios)*500:,} pixel comparisons.")
print("C++11 core compiled with warnings as errors; JavaScript matches all frames.")
print("Verified full route colours, every focus/locate checkpoint, RGB tests, minimum/default/maximum levels, offsets, disabled output and black tails.")
print("This is a host logic test, not an ESP32 target build or a physical LED test.")
