#include "../PixelTool/DeviceConfig.h"
#include <cassert>
#include <iostream>
int main() {
  device::Config c;
  assert(device::valid(c) && c.output == 2 && c.order == 0 && !c.pinEnabled);
  for (int pin = -1; pin <= 30; ++pin) {
    auto x = c;
    x.output = pin;
    assert(device::valid(x) == device::spare(pin));
  }
  for (int reserved : {4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 21, 22}) {
    auto x = c;
    x.buttons[0] = reserved;
    assert(!device::valid(x));
  }
  c.buttons[0] = 2;
  assert(!device::valid(c));
  c.buttons[0] = 3;
  assert(device::valid(c));
  c.buttons[1] = 3;
  assert(!device::valid(c));
  c.buttons[1] = 18;
  assert(device::valid(c));
  c.backlight = 51;
  assert(!device::valid(c));
  c.backlight = 4;
  assert(!device::valid(c));
  c.backlight = 50;
  assert(device::valid(c));
  c.order = 6;
  assert(!device::valid(c));
  assert(device::validPin("000000"));
  for (auto pin : {"", "12345", "1234567", "12a456", "123 56"})
    assert(!device::validPin(pin));
  assert(!device::showAP(true, false, true, 99999));
  assert(!device::showAP(false, false, true, 14999));
  assert(device::showAP(false, false, true, 15000));
  assert(device::showAP(false, true, true, 0));
  assert(device::showAP(false, false, false, 0));
  std::cout << "Configuration validation and LCD fallback tests passed\n";
}
