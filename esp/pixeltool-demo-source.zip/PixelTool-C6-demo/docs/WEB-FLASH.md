# Browser flashing and first setup

A small box, a modest plan, and hopefully fewer evenings spent arguing with pixel numbers.

## Supported hardware

This build targets the Waveshare ESP32-C6-LCD-1.47-M, SKU 30381, with the verified ESP32-C6FH8/8 MiB flash configuration and this project's fixed LCD pinout. Browser chipset detection does not identify the product or prove flash capacity. Other ESP32 boards, other LCD wiring and unverified 4 MiB units are not supported by this package.

## Choose the right firmware

The personal build includes owner-supplied model geometry. Keep it private unless redistribution rights are established.

The prepared public/demo build includes original synthetic demo grids. It retains manual Tools, test patterns, presets and the HA network receiver. HA can render any supported uploaded model to it; the HA library is not copied into standalone firmware.

Installing the demo build changes the built-in pusher models. Do not use it as an incidental update to the owner's personal model build.

## Initial browser installation

1. Disconnect external pixel power/data while flashing. Connect only the supported board to your computer with a USB data cable.
2. Open the hosted installer in a desktop browser with Web Serial support, such as Chrome or Edge. It must be served over HTTPS; localhost is suitable for a local preview. Opening index.html as file:// is not an installer.
3. Confirm the exact board/flash profile on the page, then choose Install demo firmware.
4. Select the ESP USB port. If it cannot enter download mode, hold BOOT while reconnecting USB, release it, then retry.
5. Review the erase choice carefully. A fresh merged-image install can erase settings, Wi-Fi credentials and presets. Back up an existing device first.
6. Wait for completion; do not disconnect USB during writing. The firmware restarts with pixel output off.
7. No filesystem or SD-card upload is needed.

The public demo installer is https://sheldondickinson.github.io/ha-baldrick-controller/esp/ . The matching clean demo source is available beside the installer and in the beta release assets. Do not send people to the ESP Web Tools demo: that demo installs ESPHome, not PixelTool.

## Connect to Wi-Fi

This firmware does not implement Improv Serial. The installer therefore does not automatically configure Wi-Fi.

On first boot, wait for the fallback AP details on the LCD. Join the displayed PixelTool AP and open http://192.168.4.1. In Config, choose Join Wi-Fi with fallback AP, enter your network details and save. Reopen the GUI at the device's LAN address.

Alternatively use the documented scripts/device.py WIFI flow, which accepts a private JSON file on stdin. Keep credentials out of command arguments, public logs and issues.

## Standalone testing

Open the device's Tools or Pusher page. Confirm the separately powered pixel load, voltage, data direction, colour order and common ground. Default data is GPIO2; the device/USB does not supply prop power. Start at low brightness, test a few known pixels and verify STOP/blackout physically.

## HA PixelTool destination

Retrieve the private access file once over owner-controlled USB using scripts/device.py ACCESS. Add the verified MAC/IP/kind=esp/private PIN to the companion's private configuration as described in ha-baldrick-controller. Restart the disarmed companion. HA discovers already-paired ESP devices by their advertised read interface.

Do not put the access PIN or companion bearer token in the browser bundle, repository or issue tracker.

## Updates and recovery

For ordinary compatible-profile updates, use scripts/ota_update.py with an owner-only access file. Authenticated OTA preserves NVS and uses the existing two-slot app layout. USB remains the recovery route.

Keep the exact board profile and model profile consistent. Before changing profiles, retain a full flash backup and record settings. Do not erase all flash for a routine update.

## Maintainer packaging

Run scripts/build_public.py with an output directory and the pinned Arduino CLI/core/libraries. For an owner-specific privacy check, pass --deny-file pointing to a private JSON list of identifiers that must not appear; that file is never included in output. The export copies explicit source files only. It creates a clean source export, compiles synthetic models, prepares the patched merged ESP32-C6 image, writes the manifest and SHA-256 list, and copies the browser installer. The personal source/models are not modified.

ESP Web Tools documentation: https://esphome.github.io/esp-web-tools/
