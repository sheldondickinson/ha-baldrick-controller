#pragma once
#include <stddef.h>
#include <stdint.h>
#include <string.h>

namespace Ddp {
constexpr size_t MAX_CHANNELS = 3000;
constexpr size_t MAX_PACKET = 1450;
enum class Result { Invalid, Partial, Complete };
inline bool expired(uint32_t now, uint32_t last, uint32_t timeout) {
  return int32_t(now - last) > int32_t(timeout);
}
struct Receiver {
  uint8_t pixels[MAX_CHANNELS] = {};
  uint8_t pending[MAX_CHANNELS] = {};
  bool covered[MAX_CHANNELS] = {};
  size_t channels = 0, received = 0;
  void resetFrame() {
    memset(covered, 0, sizeof(covered));
    received = 0;
  }
  void begin(size_t count) {
    channels = count <= 1000 ? count * 3 : 0;
    memset(pixels, 0, sizeof(pixels));
    memset(pending, 0, sizeof(pending));
    resetFrame();
  }
  Result packet(const uint8_t *p, size_t size) {
    if (!channels || size < 10 || size > MAX_PACKET || (p[0] & 0xFE) != 0x40 ||
        p[1] < 1 || p[1] > 15 || p[2] != 0 || p[3] != 1)
      return Result::Invalid;
    const uint32_t offset = (uint32_t(p[4]) << 24) | (uint32_t(p[5]) << 16) |
                            (uint32_t(p[6]) << 8) | p[7];
    const size_t length = (size_t(p[8]) << 8) | p[9];
    if (!length || length != size - 10 || offset > channels ||
        length > channels - offset)
      return Result::Invalid;
    if (offset == 0)
      resetFrame();
    for (size_t i = 0; i < length; ++i) {
      pending[offset + i] = p[10 + i];
      if (!covered[offset + i]) {
        covered[offset + i] = true;
        ++received;
      }
    }
    if (!(p[0] & 1))
      return Result::Partial;
    if (received != channels) {
      resetFrame();
      return Result::Invalid;
    }
    memcpy(pixels, pending, channels);
    resetFrame();
    return Result::Complete;
  }
};
} // namespace Ddp
