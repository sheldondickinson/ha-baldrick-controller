#pragma once
#include <stdint.h>
namespace device {
// Only spare, exposed GPIOs. LCD, USB, BOOT, RGB LED and SD are reserved.
constexpr int pins[] = {0, 1, 2, 3, 18, 19, 20, 23};
constexpr const char *orders[] = {"RGB", "RBG", "GRB", "GBR", "BRG", "BGR"};
struct Config {
  int output = 2;
  int buttons[4] = {-1, -1, -1, -1}; // previous, next, MARK, stop
  int order = 0;
  int backlight = 24;
  bool pinEnabled = false;
  bool ledEnabled = true;
  bool apOnly = false;
};
inline bool spare(int pin) {
  for (int allowed : pins)
    if (pin == allowed)
      return true;
  return false;
}
inline bool valid(const Config &c) {
  if (!spare(c.output) || c.order < 0 || c.order > 5 || c.backlight < 5 ||
      c.backlight > 50)
    return false;
  for (int i = 0; i < 4; ++i) {
    if (c.buttons[i] == -1)
      continue;
    if (!spare(c.buttons[i]) || c.buttons[i] == c.output)
      return false;
    for (int j = 0; j < i; ++j)
      if (c.buttons[j] == c.buttons[i])
        return false;
  }
  return true;
}
inline bool validPin(const char *pin) {
  if (!pin)
    return false;
  int i = 0;
  for (; pin[i]; ++i)
    if (i >= 6 || pin[i] < '0' || pin[i] > '9')
      return false;
  return i == 6;
}
inline bool showAP(bool connected, bool apOnly, bool hasSsid,
                   uint32_t elapsed) {
  return !connected && (apOnly || !hasSsid || elapsed >= 15000);
}
} // namespace device
