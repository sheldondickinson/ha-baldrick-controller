#include "DdpReceiver.h"
#include "DeviceConfig.h"
#include "PixelLogic.h"
#include "PusherCore.h"
#include "PusherPage.h"
#include "UiPages.h"
#include <Adafruit_NeoPixel.h>
#include <Adafruit_ST7789.h>
#include <Arduino.h>
#include <ArduinoOTA.h>
#include <ESPmDNS.h>
#include <Preferences.h>
#include <SPI.h>
#include <WebServer.h>
#include <WiFi.h>
#include <WiFiUdp.h>

// Waveshare ESP32-C6-LCD-1.47-M (30381), no touchscreen and no SD required.
constexpr int LCD_CS = 14, LCD_DC = 15, LCD_RST = 21, LCD_BL = 22;
constexpr int LCD_SCK = 7, LCD_MOSI = 6, BOOT_KEY = 9, PIXEL_PIN = 2;
const char *modes[] = {
    "Off",           "Strand cutter",  "Model guide",    "Pixel finder",
    "Pixel walk",    "Range",          "Solid red",      "Solid green",
    "Solid blue",    "Solid white",    "Rainbow",        "Pixel scan",
    "RGB wipe",      "Pusher colours", "Pusher markers", "Pusher focus",
    "Pusher locate", "Pusher red",     "Pusher green",   "Pusher blue"};
constexpr int MODE_COUNT = 20;
Adafruit_ST7789 lcd(LCD_CS, LCD_DC, LCD_RST);
Adafruit_NeoPixel strip(pixeltool::MAX_PIXELS, PIXEL_PIN, NEO_GRB + NEO_KHZ800);
WebServer server(80);
Preferences prefs;
Preferences configPrefs;
device::Config config;
Adafruit_NeoPixel statusLed(1, 8, NEO_RGB + NEO_KHZ800);
unsigned long wifiStarted = 0, reconnectAt = 0, restartAt = 0, infoUntil = 0,
              ledTestUntil = 0, feedbackUntil = 0;
bool feedbackMatch = false;
pixeltool::Model model;
Pusher::State pusher;
constexpr int PUSHER_MODE_START = 13;
const neoPixelType pusherOrders[] = {NEO_RGB, NEO_RBG, NEO_GRB,
                                     NEO_GBR, NEO_BRG, NEO_BGR};
const char *pusherNames[] = {"Demo Grid 500", "Demo Grid 350"};
bool pusherMarked = false;
int pusherDifference = 0;

String modelName = "My model", endsText = "", ssid = "", wifiPassword = "";
String apName, apPassword, accessPin;
int mode = 0, position = 1, perStrand = 125, strands = 4, tail = 0;
int rangeStart = 1, rangeEnd = 10, brightness = 15, activeTransition = 0;
bool running = false, armed = false;
bool pixelsWereActive = false, storageReady = false, apReady = false;
unsigned long lcdDraws = 0;
bool otaStarted = false;
long markDifference = 0;
bool hasMark = false;
unsigned long lastDraw = 0, lastFrame = 0, lastStep = 0, lastButton = 0,
              pressStart = 0, lastRelease = 0;
bool buttonDown = false, pendingShort = false, displayDirty = true;

constexpr const char *FIRMWARE_VERSION = "0.2.1";
WiFiUDP ddpUdp;
Ddp::Receiver ddpReceiver;
bool receiverOwned = false, receiverPixelsActive = false;
String receiverToken;
IPAddress receiverSource;
unsigned long receiverDeadline = 0, receiverLastFrame = 0;
uint32_t receiverFrames = 0, receiverDropped = 0;
int receiverCount = 0;
uint8_t lcdCycle = 0;

void receiverStop() {
  receiverOwned = false;
  receiverToken = "";
  if (receiverPixelsActive) {
    strip.clear();
    strip.show();
  }
  receiverPixelsActive = false;
  digitalWrite(config.output, LOW);
  displayDirty = true;
}
String receiverStatus() {
  String identity = WiFi.macAddress();
  identity.replace(":", "");
  identity.toLowerCase();
  return "{\"api\":\"pixeltool-ddp-v1\",\"firmware\":\"" +
         String(FIRMWARE_VERSION) + "\",\"id\":\"" + identity +
         "\",\"model\":\"PixelTool "
         "ESP32-C6\",\"capacity\":1000,\"ddp_port\":4048,\"owned\":" +
         String(receiverOwned ? "true" : "false") + ",\"standalone_active\":" +
         String(armed && running ? "true" : "false") + ",\"stream_active\":" +
         String(receiverPixelsActive ? "true" : "false") +
         ",\"frames\":" + String(receiverFrames) +
         ",\"dropped\":" + String(receiverDropped) +
         ",\"count\":" + String(receiverCount) + ",\"colour_order\":\"" +
         String(device::orders[config.order]) +
         "\",\"brightness_cap\":" + String(brightness) +
         ",\"gpio\":" + String(config.output) + "}";
}
void receiverAction() {
  if (!server.hasArg("pin") || server.arg("pin") != accessPin) {
    server.send(403, "text/plain", "Receiver access denied");
    return;
  }
  const String op = server.arg("op");
  if (op == "claim") {
    if (receiverOwned || (armed && running)) {
      server.send(409, "text/plain", "Another session controls pixel output");
      return;
    }
    int count;
    if (!integerArg("count", count, 1, 1000))
      return sendBad("Invalid receiver pixel count");
    setMode(0);
    outputFrame(millis());
    receiverSource = server.client().remoteIP();
    receiverToken = String(esp_random(), HEX) + String(esp_random(), HEX) +
                    String(esp_random(), HEX) + String(esp_random(), HEX);
    receiverCount = count;
    ddpReceiver.begin(count);
    receiverFrames = receiverDropped = 0;
    receiverOwned = true;
    receiverLastFrame = millis();
    receiverDeadline = millis() + 15000;
    displayDirty = true;
    server.send(200, "application/json",
                "{\"token\":\"" + receiverToken + "\"}");
    return;
  }
  if (!receiverOwned || server.arg("token") != receiverToken ||
      server.client().remoteIP() != receiverSource) {
    server.send(409, "text/plain", "Receiver session absent or expired");
    return;
  }
  if (op == "renew")
    receiverDeadline = millis() + 15000;
  else if (op == "release")
    receiverStop();
  else
    return sendBad("Unknown receiver operation");
  server.send(200, "application/json", receiverStatus());
}
void receiverLoop(unsigned long now) {
  if (receiverOwned && ((long)(now - receiverDeadline) >= 0 ||
                        Ddp::expired(now, receiverLastFrame, 2000)))
    receiverStop();
  for (int processed = 0; processed < 8; ++processed) {
    int size = ddpUdp.parsePacket();
    if (!size)
      break;
    if (!receiverOwned || ddpUdp.remoteIP() != receiverSource ||
        size > int(Ddp::MAX_PACKET)) {
      ddpUdp.clear();
      ++receiverDropped;
      continue;
    }
    uint8_t data[Ddp::MAX_PACKET];
    const int n = ddpUdp.read(data, sizeof(data));
    const auto result = ddpReceiver.packet(data, n > 0 ? size_t(n) : 0);
    if (result == Ddp::Result::Invalid) {
      ++receiverDropped;
      continue;
    }
    if (result != Ddp::Result::Complete)
      continue;
    const unsigned cap = brightness * 255 / 100;
    for (int i = 0; i < 1000; ++i) {
      unsigned r = 0, g = 0, b = 0;
      if (i < receiverCount) {
        r = ddpReceiver.pixels[i * 3];
        g = ddpReceiver.pixels[i * 3 + 1];
        b = ddpReceiver.pixels[i * 3 + 2];
        const unsigned peak = std::max(r, std::max(g, b));
        if (peak > cap) {
          r = r * cap / peak;
          g = g * cap / peak;
          b = b * cap / peak;
        }
      }
      strip.setPixelColor(i, strip.Color(r, g, b));
    }
    strip.show();
    receiverPixelsActive = true;
    receiverLastFrame = now;
    ++receiverFrames;
  }
}

bool inPusher() { return mode >= PUSHER_MODE_START; }
void applyPixelOrder() {
  pusher.order = config.order;
  strip.updateType(pusherOrders[config.order] + NEO_KHZ800);
}
bool persistConfig() {
  if (!storageReady)
    return false;
  // Single NVS blob commits all pin mappings and flags as one record.
  return configPrefs.putBytes("v1", &config, sizeof(config)) == sizeof(config);
}
void configurePins() {
  strip.setPin(config.output);
  pinMode(config.output, OUTPUT);
  digitalWrite(config.output, LOW);
  for (int pin : config.buttons)
    if (pin >= 0)
      pinMode(pin, INPUT_PULLUP);
  analogWrite(LCD_BL, config.backlight * 255 / 100);
}

String escapeJson(const String &s) {
  String out = "\"";
  for (size_t i = 0; i < s.length(); ++i) {
    char c = s[i];
    if (c == '"' || c == '\\') {
      out += '\\';
      out += c;
    } else if ((uint8_t)c >= 32)
      out += c;
  }
  return out + "\"";
}
bool integerArg(const String &name, int &value, int lo, int hi) {
  if (!server.hasArg(name))
    return false;
  const String s = server.arg(name);
  if (!s.length() || s.length() > 6)
    return false;
  for (size_t i = 0; i < s.length(); ++i)
    if (!isDigit(s[i]))
      return false;
  const long v = s.toInt();
  if (v < lo || v > hi)
    return false;
  value = v;
  return true;
}
bool persist() {
  if (!storageReady)
    return false;
  bool ok = true;
  ok &= prefs.putInt("start", rangeStart) == sizeof(int32_t);
  ok &= prefs.putInt("end", rangeEnd) == sizeof(int32_t);
  ok &= prefs.putInt("per", perStrand) == sizeof(int32_t);
  ok &= prefs.putInt("strands", strands) == sizeof(int32_t);
  ok &= prefs.putInt("tail", tail) == sizeof(int32_t);
  ok &= prefs.putInt("count", model.count) == sizeof(int32_t);
  ok &= prefs.putInt("bright", brightness) == sizeof(int32_t);
  ok &= prefs.putBool("rgb", config.order == 0) == 1;
  prefs.putString("name", modelName);
  prefs.putString("ends", endsText);
  prefs.putString("ssid", ssid);
  prefs.putString("pass", wifiPassword);
  ok &= prefs.getString("name") == modelName &&
        prefs.getString("ends") == endsText;
  ok &= prefs.getString("ssid") == ssid &&
        prefs.getString("pass") == wifiPassword;
  return persistConfig() && ok;
}
bool saveSettings() {
  if (persist())
    return true;
  server.send(500, "text/plain",
              "Internal flash save failed. Restart and check settings.");
  return false;
}

void setMode(int next) {
  if (receiverOwned)
    receiverStop();
  const bool wasPusher = inPusher();
  mode = pixeltool::clamp(next, 0, MODE_COUNT - 1);
  if (wasPusher != inPusher())
    armed = false;
  if (inPusher())
    pusher.mode = mode - PUSHER_MODE_START;
  applyPixelOrder();
  if (mode == 0)
    armed = false;
  running = armed && mode != 0;
  hasMark = false;
  displayDirty = true;
  lastFrame = 0;
}
void mark() {
  // MARK checks the currently selected section end against the manually
  // selected/current pixel. It cannot sense which pixel was physically pushed.
  if (mode != 2)
    return;
  markDifference = pixeltool::markDifference(model, activeTransition, position);
  hasMark = true;
  feedbackMatch = markDifference == 0;
  feedbackUntil = millis() + 1600;
  displayDirty = true;
  if (markDifference == 0 && activeTransition < model.used)
    ++activeTransition;
}
String status() {
  String j = "{";
  j += "\"mode\":" + String(mode) + ",\"modeName\":" + escapeJson(modes[mode]);
  j += ",\"armed\":" + String(armed ? "true" : "false");
  j += ",\"lcdDraws\":" + String(lcdDraws) +
       ",\"apReady\":" + String(apReady ? "true" : "false");
  j += ",\"storageReady\":" + String(storageReady ? "true" : "false");
  j += ",\"running\":" + String(running ? "true" : "false");
  j +=
      ",\"position\":" + String(position) + ",\"count\":" + String(model.count);
  j += ",\"per\":" + String(perStrand) + ",\"strands\":" + String(strands);
  j += ",\"tail\":" + String(tail) +
       ",\"total\":" + String(pixeltool::cutTotal(perStrand, strands, tail));
  j += ",\"start\":" + String(rangeStart) + ",\"end\":" + String(rangeEnd);
  j += ",\"brightness\":" + String(brightness) +
       ",\"order\":" + escapeJson(device::orders[config.order]);
  j += ",\"model\":" + escapeJson(modelName) +
       ",\"ends\":" + escapeJson(endsText);
  j += ",\"selected\":" + String(activeTransition) +
       ",\"expected\":" + String(pixeltool::expected(model, activeTransition));
  j += ",\"sections\":" + String(model.used + 1) +
       ",\"marked\":" + String(hasMark ? "true" : "false");
  j += ",\"difference\":" + String(markDifference);
  j += ",\"pusherModel\":" + String(pusher.model) +
       ",\"pusherNode\":" + String(pusher.node);
  j += ",\"wifi\":" + escapeJson(WiFi.status() == WL_CONNECTED
                                     ? WiFi.localIP().toString()
                                     : "offline");
  j += ",\"pinEnabled\":" + String(config.pinEnabled ? "true" : "false");
  j += ",\"outputPin\":" + String(config.output);
  j += ",\"lcdView\":" +
       escapeJson((infoUntil ||
                   device::showAP(WiFi.status() == WL_CONNECTED, config.apOnly,
                                  ssid.length(), millis() - wifiStarted))
                      ? "connection"
                      : "pixels");
  j += ",\"ledEnabled\":" + String(config.ledEnabled ? "true" : "false");
  j +=
      ",\"receiverOwned\":" + String(receiverOwned ? "true" : "false") +
      ",\"receiverActive\":" + String(receiverPixelsActive ? "true" : "false") +
      ",\"lcdStatusCycle\":" + String(lcdCycle);
  return j + "}";
}
void sendBad(const char *why) { server.send(400, "text/plain", why); }
bool authorised() {
  if (!config.pinEnabled ||
      (server.hasArg("pin") && server.arg("pin") == accessPin))
    return true;
  server.send(403, "text/plain", "Enter the access PIN set in Configuration.");
  return false;
}
void sendPusherState() {
  String j =
      "{\"model\":" + String(pusher.model) + ",\"mode\":" + String(pusher.mode);
  j += ",\"run\":" + String(pusher.run) + ",\"node\":" + String(pusher.node);
  j += ",\"level\":" + String(pusher.level) +
       ",\"first\":" + String(pusher.first);
  j += ",\"order\":" + String(pusher.order) + ",\"enabled\":" +
       String(inPusher() && armed && running ? "true" : "false");
  j += ",\"active\":" + String(inPusher() ? "true" : "false") +
       ",\"gpio\":" + String(config.output);
  j += ",\"cap\":" + String(brightness * 255 / 100) +
       ",\"marked\":" + String(pusherMarked ? "true" : "false");
  j += ",\"difference\":" + String(pusherDifference) + ",\"expected\":" +
       String(MODELS[pusher.model].checkpoints[pusher.run].node) + "}";
  j.remove(j.length() - 1);
  j += ",\"pinEnabled\":" + String(config.pinEnabled ? "true" : "false");
  j += ",\"globalRunning\":" + String(armed && running ? "true" : "false") +
       ",\"globalMode\":" + escapeJson(modes[mode]) + "}";
  server.sendHeader("Cache-Control", "no-store");
  server.send(200, "application/json", j);
}
void markPusher() {
  pusherDifference =
      int(pusher.node) - int(MODELS[pusher.model].checkpoints[pusher.run].node);
  pusherMarked = true;
  feedbackMatch = pusherDifference == 0;
  feedbackUntil = millis() + 1600;
  displayDirty = true;
}
void handlePusherMark() {
  if (!authorised())
    return;
  if (!inPusher())
    return sendBad("Select a Pixel Pusher mode first");
  markPusher();
  sendPusherState();
}
void changePusherState() {
  if (receiverOwned &&
      !(server.arg("op") == "stop" ||
        (server.arg("op") == "mode" && server.arg("value") == "0"))) {
    server.send(409, "text/plain",
                "HA PixelTool controls output; stop/release it first");
    return;
  }
  if (!authorised())
    return;
  Pusher::State next = pusher;
  int n;
  bool mappingChanged = false, hasMode = false, hasEnable = false;
  bool enabled = inPusher() && armed && running;
  if (server.hasArg("model")) {
    if (!integerArg("model", n, 0, MODEL_COUNT - 1))
      return sendBad("Invalid prop");
    if (next.model != n) {
      next.model = n;
      next.first = 1;
      next.node = 1;
      next.run = 0;
      mappingChanged = true;
    }
  }
  for (int i = 0; i < server.args(); ++i) {
    String key = server.argName(i);
    if (key == "pin" || key == "model")
      continue;
    const Model &m = MODELS[next.model];
    if (key == "mode") {
      if (!integerArg(key, n, 0, Pusher::TEST_BLUE))
        return sendBad("Invalid pusher mode");
      next.mode = n;
      hasMode = true;
    } else if (key == "run") {
      if (!integerArg(key, n, 0, m.checkpointCount - 1))
        return sendBad("Invalid checkpoint");
      next.run = n;
    } else if (key == "node") {
      if (!integerArg(key, n, 1, m.count))
        return sendBad("Invalid model node");
      next.node = n;
    } else if (key == "first") {
      if (!integerArg(key, n, 1, m.count))
        return sendBad("Invalid first node");
      mappingChanged |= next.first != n;
      next.first = n;
      next.node = n;
      next.run = Pusher::runForNode(m, n);
    } else if (key == "level") {
      if (!integerArg(key, n, 1, 64))
        return sendBad("Pusher brightness must be 1 to 64");
      next.level = n;
    } else if (key == "order") {
      if (!integerArg(key, n, 0, 5))
        return sendBad("Invalid colour order");
      next.order = n;
    } else if (key == "enabled") {
      if (!integerArg(key, n, 0, 1))
        return sendBad("Invalid enable value");
      enabled = n;
      hasEnable = true;
    } else
      return sendBad("Unknown pusher field");
  }
  if (!Pusher::valid(next))
    return sendBad("Invalid pusher state");
  // Mapping changes always disarm, even if enable is included in the same
  // request.
  if (mappingChanged) {
    setMode(0);
    outputFrame(millis());
    enabled = false;
  }
  config.order = next.order;
  pusher = next;
  pusher.enabled = false;
  pusherMarked = false;
  if (hasMode || mappingChanged || (hasEnable && enabled))
    setMode(PUSHER_MODE_START + pusher.mode);
  if (hasEnable && !enabled) {
    setMode(0);
    outputFrame(millis());
  } else if (inPusher()) {
    armed = enabled;
    running = enabled;
  }
  applyPixelOrder();
  displayDirty = true;
  sendPusherState();
}
void savePusherSetup() {
  if (!authorised())
    return;
  bool ok = persistConfig();
  ok &= prefs.putUChar("pushModel", pusher.model) == 1;
  ok &= prefs.putUChar("pushLevel", pusher.level) == 1;
  ok &= prefs.putUChar("pushOrder", pusher.order) == 1;
  ok &= prefs.putUShort("pushFirst", pusher.first) == 2;
  if (!ok) {
    server.send(500, "text/plain", "Pusher setup save failed");
    return;
  }
  sendPusherState();
}

void handleAction() {
  if (receiverOwned &&
      !(server.arg("op") == "stop" ||
        (server.arg("op") == "mode" && server.arg("value") == "0"))) {
    server.send(409, "text/plain",
                "HA PixelTool controls output; stop/release it first");
    return;
  }
  if (!authorised())
    return;
  const String op = server.arg("op");
  int n;
  if (op == "mode") {
    if (!integerArg("value", n, 0, MODE_COUNT - 1))
      return sendBad("Invalid mode");
    setMode(n);
  } else if (op == "position") {
    if (!integerArg("value", n, 1, model.count))
      return sendBad("Invalid pixel");
    position = n;
    hasMark = false;
    displayDirty = true;
  } else if (op == "next") {
    position = pixeltool::clamp(position + 1, 1, model.count);
    hasMark = false;
    displayDirty = true;
  } else if (op == "prev") {
    position = pixeltool::clamp(position - 1, 1, model.count);
    hasMark = false;
    displayDirty = true;
  } else if (op == "mark") {
    if (mode != 2)
      return sendBad("Select Model guide before MARK");
    mark();
  } else if (op == "arm") {
    if (mode == 0)
      return sendBad("Select a mode first");
    armed = true;
    running = true;
    displayDirty = true;
  } else if (op == "selected") {
    if (!integerArg("value", n, 0, model.used))
      return sendBad("Invalid section");
    activeTransition = n;
    hasMark = false;
    displayDirty = true;
  } else if (op == "savePreset") {
    if (!integerArg("value", n, 0, 3))
      return sendBad("Invalid preset");
    String prefix = "p" + String(n);
    prefs.putString((prefix + "name").c_str(), modelName);
    prefs.putString((prefix + "ends").c_str(), endsText);
    prefs.putInt((prefix + "count").c_str(), model.count);
    if (!storageReady ||
        prefs.getString((prefix + "name").c_str()) != modelName ||
        prefs.getString((prefix + "ends").c_str()) != endsText ||
        prefs.getInt((prefix + "count").c_str(), 0) != model.count) {
      server.send(500, "text/plain", "Preset save failed");
      return;
    }
  } else if (op == "loadPreset") {
    if (!integerArg("value", n, 0, 3))
      return sendBad("Invalid preset");
    String prefix = "p" + String(n);
    if (!prefs.isKey((prefix + "count").c_str()))
      return sendBad("Preset is empty");
    int count = prefs.getInt((prefix + "count").c_str(), 500);
    String ends = prefs.getString((prefix + "ends").c_str(), "");
    pixeltool::Model candidate;
    if (!pixeltool::parseEnds(ends.c_str(), candidate, count))
      return sendBad("Invalid saved preset");
    model = candidate;
    modelName = prefs.getString((prefix + "name").c_str(), "Model");
    endsText = ends;
    position = 1;
    activeTransition = 0;
    hasMark = false;
    rangeStart = pixeltool::clamp(rangeStart, 1, model.count);
    rangeEnd = pixeltool::clamp(rangeEnd, rangeStart, model.count);
    if (!saveSettings())
      return;
    displayDirty = true;
  } else if (op == "stop")
    setMode(0);
  else
    return sendBad("Unknown action");
  server.send(200, "application/json", status());
}
void handleSettings() {
  if (!authorised())
    return;
  int per, ns, t, br = brightness, count, start, end;
  if (!integerArg("per", per, 1, 1000) || !integerArg("strands", ns, 1, 32) ||
      !integerArg("tail", t, 0, 100) || pixeltool::cutTotal(per, ns, t) < 0 ||
      (server.hasArg("brightness") && !integerArg("brightness", br, 1, 30)) ||
      !integerArg("count", count, 1, 1000) ||
      !integerArg("start", start, 1, count) ||
      !integerArg("end", end, start, count))
    return sendBad("Check numbers: maximum 1000 pixels and brightness 30%.");
  String raw = server.arg("ends");
  if (raw.length() > 480)
    return sendBad("Too many boundaries");
  pixeltool::Model candidate;
  if (!pixeltool::parseEnds(raw.c_str(), candidate, count))
    return sendBad("Section ends must increase and be below model total.");
  String name = server.arg("name");
  name.trim();
  if (name.length() > 38 || name.length() == 0)
    return sendBad("Enter a model name up to 38 characters.");
  int newOrder = config.order;
  if (server.hasArg("order")) {
    newOrder = -1;
    for (int i = 0; i < 6; ++i)
      if (server.arg("order") == device::orders[i])
        newOrder = i;
    if (newOrder < 0)
      return sendBad("Invalid colour order");
  }
  perStrand = per;
  strands = ns;
  tail = t;
  brightness = br;
  model = candidate;
  modelName = name;
  endsText = raw;
  rangeStart = start;
  rangeEnd = end;
  position = pixeltool::clamp(position, 1, model.count);
  activeTransition = pixeltool::clamp(activeTransition, 0, model.used);
  config.order = newOrder;
  applyPixelOrder();
  hasMark = false;
  if (!saveSettings())
    return;
  displayDirty = true;
  server.send(200, "application/json", status());
}
void handleWifi() {
  if (!authorised())
    return;
  String newSsid = server.arg("ssid"), newPass = server.arg("password");
  if (server.hasArg("keepPassword") && server.arg("keepPassword") == "1" &&
      !newPass.length())
    newPass = wifiPassword;
  if (newSsid.length() > 32 || newPass.length() > 63 ||
      (newPass.length() && newPass.length() < 8))
    return sendBad("Invalid Wi-Fi details");
  int apOnly = config.apOnly;
  if (server.hasArg("apOnly") && !integerArg("apOnly", apOnly, 0, 1))
    return sendBad("Invalid network mode");
  bool oldAPOnly = config.apOnly;
  config.apOnly = apOnly;
  String oldSsid = ssid, oldPass = wifiPassword;
  ssid = newSsid;
  wifiPassword = newPass;
  if (!saveSettings()) {
    ssid = oldSsid;
    wifiPassword = oldPass;
    config.apOnly = oldAPOnly;
    return;
  }
  setMode(0);
  outputFrame(millis());
  reconnectAt = millis() + 700;
  server.send(200, "text/plain",
              "Wi-Fi saved. Reconnecting; the fallback AP remains available.");
}

void sendAsset(const uint8_t *data, size_t size, const char *type) {
  server.sendHeader("Content-Encoding", "gzip");
  server.sendHeader("Cache-Control", "no-store");
  server.send_P(200, type, (const char *)data, size);
}
void sendConfig() {
  String j = "{\"output\":" + String(config.output) +
             ",\"order\":" + String(config.order);
  j += ",\"buttons\":[";
  for (int i = 0; i < 4; ++i)
    j += (i ? "," : "") + String(config.buttons[i]);
  j += "],\"pinEnabled\":" + String(config.pinEnabled ? "true" : "false");
  j += ",\"ledEnabled\":" + String(config.ledEnabled ? "true" : "false");
  j += ",\"apOnly\":" + String(config.apOnly ? "true" : "false");
  j += ",\"backlight\":" + String(config.backlight) +
       ",\"brightness\":" + String(brightness);
  j += ",\"ssid\":" + escapeJson(ssid) + ",\"wifi\":" +
       escapeJson(WiFi.status() == WL_CONNECTED ? WiFi.localIP().toString()
                                                : "offline");
  j += ",\"apName\":" + escapeJson(apName) +
       ",\"allowedPins\":[0,1,2,3,18,19,20,23]}";
  server.sendHeader("Cache-Control", "no-store");
  server.send(200, "application/json", j);
}
void changeConfig() {
  if (!authorised())
    return;
  device::Config next = config;
  int n, newBrightness = brightness;
  for (int i = 0; i < server.args(); ++i) {
    String key = server.argName(i);
    if (key == "pin" || key == "newPin")
      continue;
    if (key == "output") {
      if (!integerArg(key, n, 0, 23))
        return sendBad("Invalid output GPIO");
      next.output = n;
    } else if (key.startsWith("button") && key.length() == 7 && key[6] >= '0' &&
               key[6] <= '3') {
      if (server.arg(key) == "-1")
        n = -1;
      else if (!integerArg(key, n, 0, 23))
        return sendBad("Invalid button GPIO");
      next.buttons[key[6] - '0'] = n;
    } else if (key == "order") {
      if (!integerArg(key, n, 0, 5))
        return sendBad("Invalid colour order");
      next.order = n;
    } else if (key == "brightness") {
      if (!integerArg(key, newBrightness, 1, 30))
        return sendBad("Brightness must be 1 to 30%");
    } else if (key == "backlight") {
      if (!integerArg(key, n, 5, 50))
        return sendBad("LCD brightness must be 5 to 50%");
      next.backlight = n;
    } else if (key == "pinEnabled" || key == "ledEnabled" || key == "apOnly") {
      if (!integerArg(key, n, 0, 1))
        return sendBad("Invalid toggle");
      if (key == "pinEnabled")
        next.pinEnabled = n;
      if (key == "ledEnabled")
        next.ledEnabled = n;
      if (key == "apOnly")
        next.apOnly = n;
    } else
      return sendBad("Unknown configuration field");
  }
  if (!device::valid(next))
    return sendBad("Pins must be spare GPIOs, without duplicates. LCD, LED, "
                   "USB, BOOT and SD pins are reserved.");
  String newPin = server.arg("newPin");
  if (newPin.length() && !device::validPin(newPin.c_str()))
    return sendBad("PIN must contain exactly six digits");
  if (next.pinEnabled && !config.pinEnabled && !newPin.length())
    return sendBad("Choose a six-digit PIN when enabling protection");
  if (!storageReady) {
    server.send(500, "text/plain", "Internal flash unavailable");
    return;
  }
  const device::Config old = config;
  const int oldBrightness = brightness;
  const String oldPin = accessPin;
  if (newPin.length())
    accessPin = newPin;
  configPrefs.putString("access", accessPin);
  if (configPrefs.getString("access") != accessPin) {
    accessPin = oldPin;
    server.send(500, "text/plain", "PIN save failed");
    return;
  }
  // Black out on the OLD output before releasing any assigned pins.
  setMode(0);
  outputFrame(millis());
  digitalWrite(old.output, LOW);
  config = next;
  brightness = newBrightness;
  if (!persist()) {
    config = old;
    brightness = oldBrightness;
    accessPin = oldPin;
    configPrefs.putString("access", oldPin);
    persist();
    server.send(500, "text/plain", "Configuration save failed; output is off");
    return;
  }
  for (int pin : old.buttons)
    if (pin >= 0)
      pinMode(pin, INPUT);
  pinMode(old.output, INPUT_PULLDOWN);
  configurePins();
  applyPixelOrder();
  if (otaStarted)
    ArduinoOTA.setPassword(accessPin.c_str());
  if (old.apOnly != config.apOnly)
    reconnectAt = millis() + 700;
  displayDirty = true;
  sendConfig();
}
void deviceAction() {
  if (!authorised())
    return;
  String op = server.arg("op");
  if (op == "stop") {
    receiverStop();
    setMode(0);
    outputFrame(millis());
  } else if (op == "info") {
    infoUntil = millis() + 20000;
    displayDirty = true;
  } else if (op == "ledTest")
    ledTestUntil = millis() + 3000;
  else if (op == "restart") {
    setMode(0);
    outputFrame(millis());
    restartAt = millis() + 700;
  } else
    return sendBad("Unknown device action");
  server.send(200, "text/plain",
              op == "restart" ? "Restarting; pixel output stays off" : "Done");
}
void extraButtons(unsigned long now) {
  static int previousPins[4] = {-1, -1, -1, -1};
  static bool raw[4] = {}, stable[4] = {};
  static unsigned long changed[4] = {};
  for (int i = 0; i < 4; ++i) {
    if (config.buttons[i] != previousPins[i]) {
      previousPins[i] = config.buttons[i];
      raw[i] = stable[i] =
          config.buttons[i] >= 0 && digitalRead(config.buttons[i]) == LOW;
      changed[i] = now;
    }
    if (config.buttons[i] < 0)
      continue;
    bool pressed = digitalRead(config.buttons[i]) == LOW;
    if (pressed != raw[i]) {
      raw[i] = pressed;
      changed[i] = now;
    }
    if (now - changed[i] < 35 || pressed == stable[i])
      continue;
    stable[i] = pressed;
    if (!pressed)
      continue;
    if (i == 3) {
      setMode(0);
      outputFrame(now);
    } else if (i == 2) {
      if (inPusher())
        markPusher();
      else
        mark();
    } else {
      if (inPusher()) {
        pusher.node = pixeltool::clamp(int(pusher.node) + (i == 0 ? -1 : 1), 1,
                                       MODELS[pusher.model].count);
        pusherMarked = false;
      } else {
        position =
            pixeltool::clamp(position + (i == 0 ? -1 : 1), 1, model.count);
        hasMark = false;
      }
      displayDirty = true;
    }
  }
}
void ledLoop(unsigned long now) {
  uint32_t colour = 0;
  if (ledTestUntil && (long)(ledTestUntil - now) > 0) {
    unsigned long left = ledTestUntil - now;
    colour = left > 2000   ? statusLed.Color(14, 0, 0)
             : left > 1000 ? statusLed.Color(0, 14, 0)
                           : statusLed.Color(0, 0, 14);
  } else if (config.ledEnabled) {
    if (feedbackUntil && (long)(feedbackUntil - now) > 0)
      colour =
          feedbackMatch ? statusLed.Color(0, 18, 0) : statusLed.Color(18, 0, 0);
    else if (running || receiverPixelsActive) {
      unsigned int step = (now / 80) % 24;
      colour = statusLed.Color(0, 0, 3 + (step < 12 ? step : 23 - step));
    } else if (WiFi.status() != WL_CONNECTED)
      colour = (now / 650) % 2 ? statusLed.Color(12, 5, 0) : 0;
    else
      colour = statusLed.Color(0, 5, 0);
  }
  static uint32_t last = 0xFFFFFFFF;
  if (colour != last) {
    statusLed.setPixelColor(0, colour);
    statusLed.show();
    last = colour;
  }
}

void textLine(int y, const String &text, uint16_t colour = ST77XX_WHITE,
              int size = 2) {
  lcd.setTextSize(size);
  lcd.setTextColor(colour);
  lcd.setCursor(2, y);
  lcd.print(text);
}
void draw() {
  ++lcdDraws;
  lcd.fillScreen(ST77XX_BLACK);
  lcd.setTextWrap(false);
  const bool outputOn = running || receiverPixelsActive;
  textLine(10, outputOn ? "OUTPUT ON" : "OUTPUT OFF",
           outputOn ? ST77XX_GREEN : ST77XX_CYAN);
  lcd.drawFastHLine(2, 36, 168, ST77XX_WHITE);
  if (infoUntil || device::showAP(WiFi.status() == WL_CONNECTED, config.apOnly,
                                  ssid.length(), millis() - wifiStarted)) {
    textLine(50, "CONNECT TO AP", ST77XX_YELLOW);
    textLine(84, apName);
    textLine(116, "Password", ST77XX_CYAN);
    textLine(140, apPassword);
    textLine(182, "192.168.4.1");
    textLine(220, config.pinEnabled ? "PIN " + accessPin : "PIN disabled");
    if (WiFi.status() == WL_CONNECTED) {
      textLine(258, "LAN", ST77XX_CYAN);
      textLine(282, WiFi.localIP().toString());
    } else
      textLine(272, "AP ready", ST77XX_GREEN);
    return;
  }
  const char *shortModes[] = {
      "PIXEL TOOL",   "STRAND CUTTER", "MODEL GUIDE", "PIXEL FINDER",
      "PIXEL WALK",   "RANGE",         "SOLID RED",   "SOLID GREEN",
      "SOLID BLUE",   "SOLID WHITE",   "RAINBOW",     "PIXEL SCAN",
      "RGB WIPE",     "COLOUR RUNS",   "MARKERS",     "FOCUS RUN",
      "LOCATE PIXEL", "RED TEST",      "GREEN TEST",  "BLUE TEST"};
  textLine(52, receiverOwned ? "HA PIXELTOOL" : shortModes[mode],
           ST77XX_YELLOW);
  textLine(84, receiverOwned ? "NETWORK RECEIVER"
               : inPusher()
                   ? (pusher.model == 0 ? "DEMO GRID 500" : "DEMO GRID 350")
                   : modelName.substring(0, 14));
  textLine(116,
           receiverOwned ? "PIXELS"
           : mode == 1   ? "CUT AFTER"
                         : "PIXEL",
           ST77XX_CYAN);
  textLine(146,
           String(receiverOwned ? receiverCount
                  : mode == 1   ? pixeltool::cutTotal(perStrand, strands, tail)
                                : (inPusher() ? pusher.node : position)),
           ST77XX_WHITE, 5);
  if (receiverOwned)
    textLine(203, "FRAMES " + String(receiverFrames));
  else if (mode == 1)
    textLine(203, String(strands) + " x " + String(perStrand));
  else
    textLine(203, "OF " + String(inPusher() ? MODELS[pusher.model].count
                                            : model.count));
  if (receiverOwned)
    textLine(238, "GPIO " + String(config.output));
  else if (inPusher())
    textLine(238,
             "CHECK " +
                 String(MODELS[pusher.model].checkpoints[pusher.run].node));
  else if (mode == 2)
    textLine(238,
             "END " + String(pixeltool::expected(model, activeTransition)));
  else if (mode == 1)
    textLine(238, "TAIL " + String(tail));
  else
    textLine(238, "GPIO " + String(config.output));
  if (!running && !receiverOwned && lcdCycle == 2)
    textLine(258, "SMALL BOX. BIG IDEAS.", ST77XX_CYAN, 1);
  bool marked = inPusher() ? pusherMarked : hasMark;
  long difference = inPusher() ? pusherDifference : markDifference;
  if (lcdCycle == 1)
    textLine(278,
             WiFi.status() == WL_CONNECTED ? WiFi.localIP().toString()
                                           : "192.168.4.1",
             ST77XX_GREEN);
  else if (lcdCycle == 2)
    textLine(278,
             receiverOwned ? "DDP " + String(receiverCount)
                           : "GPIO " + String(config.output),
             ST77XX_CYAN);
  else if (marked)
    textLine(278, difference == 0 ? "MATCH" : "DIFF " + String(difference),
             difference == 0 ? ST77XX_GREEN : ST77XX_RED);
  else
    textLine(278,
             String(device::orders[config.order]) + "  " + String(brightness) +
                 "% CAP",
             ST77XX_CYAN);
}
void outputFrame(unsigned long now) {
  const uint8_t base = (uint8_t)(brightness * 255 / 100);
  const uint8_t pulse =
      (uint8_t)(base *
                (45 + 55 *
                          ((now / 100) % 12 < 6 ? ((now / 100) % 6)
                                                : 11 - ((now / 100) % 12)) /
                          5) /
                100); // bounded by cap
  if (receiverOwned)
    return;
  const bool active = armed && running && mode != 0;
  // With output disabled, send a single blackout only if previously active,
  // then hold the configured output low. UI verification never emits pixel
  // frames.
  if (!active) {
    if (pixelsWereActive) {
      strip.clear();
      strip.show();
      pixelsWereActive = false;
    }
    digitalWrite(config.output, LOW);
    return;
  }
  pixelsWereActive = true;
  for (int i = 0; i < pixeltool::MAX_PIXELS; ++i) {
    pixeltool::RGB c = {0, 0, 0};
    if (inPusher()) {
      auto pc =
          Pusher::physicalColour(pusher, i, base, active, (now % 1200) < 600);
      c = {pc.r, pc.g, pc.b};
    } else if (active)
      c = pixeltool::colour(i, mode, position, rangeStart, rangeEnd, perStrand,
                            strands, tail, model, base, pulse, now);
    strip.setPixelColor(i, strip.Color(c.r, c.g, c.b));
  }
  strip.show();
}
void shortPress() {
  if (inPusher()) {
    pusher.run =
        std::min<int>(pusher.run + 1, MODELS[pusher.model].checkpointCount - 1);
    pusher.node = MODELS[pusher.model].checkpoints[pusher.run].node;
    pusherMarked = false;
  } else if (mode == 2 || mode == 3 || mode == 4)
    position = pixeltool::clamp(position + 1, 1, model.count);
  else
    setMode((mode + 1) % MODE_COUNT);
  displayDirty = true;
}
void buttonLoop(unsigned long now) {
  const bool pressed = digitalRead(BOOT_KEY) == LOW;
  if (pressed != buttonDown && now - lastButton > 35) {
    buttonDown = pressed;
    lastButton = now;
    if (pressed)
      pressStart = now;
    else if (now - pressStart >= 750) {
      pendingShort = false;
      if (inPusher())
        markPusher();
      else if (mode == 2)
        mark();
      else if (mode != 0) {
        armed = !armed;
        running = armed;
        displayDirty = true;
      }
    } else if (pendingShort && now - lastRelease < 340) {
      pendingShort = false;
      setMode((mode + 1) % MODE_COUNT);
    } else {
      pendingShort = true;
      lastRelease = now;
    }
  }
  if (pendingShort && now - lastRelease >= 340) {
    pendingShort = false;
    shortPress();
  }
}
void setup() {
  Serial.begin(115200);
  pinMode(BOOT_KEY, INPUT_PULLUP);
  pinMode(LCD_BL, OUTPUT);
  analogWrite(LCD_BL, 60); // below Waveshare 50% limit
  SPI.begin(LCD_SCK, -1, LCD_MOSI, LCD_CS);
  lcd.init(172, 320);
  lcd.setRotation(0);
  storageReady = prefs.begin("pixeltool", false);
  storageReady &= configPrefs.begin("pt-config", false);
  if (configPrefs.getBytesLength("v1") == sizeof(config))
    configPrefs.getBytes("v1", &config, sizeof(config));
  if (!device::valid(config))
    config = device::Config{};
  // First upgrade uses RGB and no PIN; existing models, presets and Wi-Fi
  // survive.
  configurePins();
  statusLed.begin();
  statusLed.clear();
  statusLed.show();
  pusher.model = prefs.getUChar("pushModel", 0);
  pusher.level = prefs.getUChar("pushLevel", 32);
  pusher.order = config.order;
  pusher.first = prefs.getUShort("pushFirst", 1);
  if (!Pusher::valid(pusher)) {
    pusher = Pusher::State{};
    pusher.order = config.order;
  }
  pusher.node = pusher.first;
  pusher.run = Pusher::runForNode(MODELS[pusher.model], pusher.first);
  pusher.enabled = false;
  perStrand = pixeltool::clamp(prefs.getInt("per", 125), 1, 1000);
  strands = pixeltool::clamp(prefs.getInt("strands", 4), 1, 32);
  tail = pixeltool::clamp(prefs.getInt("tail", 0), 0, 100);
  if (pixeltool::cutTotal(perStrand, strands, tail) < 0) {
    perStrand = 125;
    strands = 4;
    tail = 0;
  }
  brightness = pixeltool::clamp(prefs.getInt("bright", 15), 1, 30);
  modelName = prefs.getString("name", "My model");
  endsText = prefs.getString("ends", "");
  int count = pixeltool::clamp(prefs.getInt("count", 500), 1, 1000);
  if (!pixeltool::parseEnds(endsText.c_str(), model, count)) {
    endsText = "";
    pixeltool::parseEnds("", model, count);
  }
  rangeStart = pixeltool::clamp(prefs.getInt("start", 1), 1, model.count);
  rangeEnd = pixeltool::clamp(prefs.getInt("end", 10), rangeStart, model.count);
  ssid = prefs.getString("ssid", "");
  wifiPassword = prefs.getString("pass", "");
  applyPixelOrder();
  strip.begin();
  strip.clear();
  digitalWrite(config.output, LOW);
  uint32_t key = esp_random();
  apName = "PixelTool-" + String(key & 0xFFFF, HEX);
  apPassword = "PT-" + String(key, HEX) + "-A";
  accessPin = configPrefs.getString("access", "");
  if (!device::validPin(accessPin.c_str()))
    accessPin = String(100000 + (esp_random() % 900000));
  configPrefs.putString("access", accessPin);
  WiFi.mode(WIFI_AP_STA);
  apReady = WiFi.softAP(apName.c_str(), apPassword.c_str());
  wifiStarted = millis();
  if (ssid.length() && !config.apOnly)
    WiFi.begin(ssid.c_str(), wifiPassword.c_str());
  server.on("/", HTTP_GET, [] {
    sendAsset(TOOLS_GZ, sizeof(TOOLS_GZ), "text/html; charset=utf-8");
  });
  server.on("/config", HTTP_GET, [] {
    sendAsset(CONFIG_GZ, sizeof(CONFIG_GZ), "text/html; charset=utf-8");
  });
  server.on("/ui.css", HTTP_GET,
            [] { sendAsset(STYLE_GZ, sizeof(STYLE_GZ), "text/css"); });
  server.on("/common.js", HTTP_GET, [] {
    sendAsset(COMMON_GZ, sizeof(COMMON_GZ), "application/javascript");
  });
  server.on("/api/config", HTTP_GET, sendConfig);
  server.on("/api/config", HTTP_POST, changeConfig);
  server.on("/api/device", HTTP_POST, deviceAction);
  server.on("/status", HTTP_GET,
            [] { server.send(200, "application/json", status()); });
  server.on("/action", HTTP_POST, handleAction);
  server.on("/settings", HTTP_POST, handleSettings);
  server.on("/wifi", HTTP_POST, handleWifi);
  server.on("/pusher", HTTP_GET, [] {
    server.sendHeader("Content-Encoding", "gzip");
    server.sendHeader("Cache-Control", "no-store");
    server.send_P(200, "text/html; charset=utf-8", (const char *)PUSHER_PAGE_GZ,
                  sizeof(PUSHER_PAGE_GZ));
  });
  server.on("/api/pusher/state", HTTP_GET, sendPusherState);
  server.on("/api/pusher/set", HTTP_POST, changePusherState);
  server.on("/api/pusher/save", HTTP_POST, savePusherSetup);
  server.on("/api/pusher/mark", HTTP_POST, handlePusherMark);
  server.on("/api/receiver", HTTP_GET,
            [] { server.send(200, "application/json", receiverStatus()); });
  server.on("/api/receiver", HTTP_POST, receiverAction);
  ddpUdp.begin(4048);
  server.begin();
  draw();
  Serial.println(
      "PixelTool C6 mobile ready; LCD 172x320; OUTPUT OFF; no SD required.");
  Serial.println(
      "USB commands: STATUS, ACCESS (private), WIFI (private), JOIN, REBOOT");
  Serial.println(status());
}
void serialLoop() {
  static String command;
  while (Serial.available()) {
    char c = Serial.read();
    if (c == '\n') {
      if (command.endsWith("\r"))
        command.remove(command.length() - 1);
      if (command == "STATUS")
        Serial.println(status());
      else if (command == "ACCESS") {
        // Credentials are disclosed only on explicit local USB request.
        Serial.println("{\"ssid\":" + escapeJson(apName) +
                       ",\"password\":" + escapeJson(apPassword) +
                       ",\"pin\":" + escapeJson(accessPin) + "}");
      } else if (command.startsWith("WIFI\t")) {
        int split = command.indexOf('\t', 5);
        String newSsid = command.substring(5, split);
        String newPass = command.substring(split + 1);
        if (split < 6 || newSsid.length() > 32 || newPass.length() > 63 ||
            (newPass.length() > 0 && newPass.length() < 8)) {
          Serial.println("WIFI invalid parameters");
        } else {
          ssid = newSsid;
          wifiPassword = newPass;
          config.apOnly = false;
          if (persist()) {
            wifiStarted = millis();
            WiFi.begin(ssid.c_str(), wifiPassword.c_str());
            Serial.println("WIFI saved; connecting (credentials hidden)");
          } else
            Serial.println("WIFI save failed");
        }
      } else if (command == "JOIN") {
        setMode(0);
        outputFrame(millis());
        config.apOnly = false;
        if (persistConfig()) {
          wifiStarted = millis();
          WiFi.begin(ssid.c_str(), wifiPassword.c_str());
          Serial.println("JOIN: connecting using saved Wi-Fi; output off");
        } else
          Serial.println("JOIN: internal flash save failed");
      } else if (command == "REBOOT") {
        setMode(0);
        outputFrame(millis());
        Serial.flush();
        ESP.restart();
      }
      command = "";
    } else if (command.length() < 128)
      command += c;
  }
}
void loop() {
  serialLoop();
  unsigned long now = millis();
  server.handleClient();
  receiverLoop(millis());
  const uint8_t cycle = (now / 4000) % 3;
  if (cycle != lcdCycle) {
    lcdCycle = cycle;
    displayDirty = true;
  }
  buttonLoop(now);
  extraButtons(now);
  ledLoop(now);
  if (restartAt && (long)(now - restartAt) >= 0)
    ESP.restart();
  if (reconnectAt && (long)(now - reconnectAt) >= 0) {
    reconnectAt = 0;
    WiFi.disconnect(false, false);
    wifiStarted = now;
    if (!config.apOnly && ssid.length())
      WiFi.begin(ssid.c_str(), wifiPassword.c_str());
  }
  if (infoUntil && (long)(now - infoUntil) >= 0) {
    infoUntil = 0;
    displayDirty = true;
  }
  static bool lastConnected = false, lastAPView = false;
  const bool connected = WiFi.status() == WL_CONNECTED;
  const bool apView = device::showAP(connected, config.apOnly, ssid.length(),
                                     now - wifiStarted);
  if (lastConnected != connected || lastAPView != apView)
    displayDirty = true;
  lastConnected = connected;
  lastAPView = apView;
  if (!otaStarted && WiFi.status() == WL_CONNECTED) {
    ArduinoOTA.setHostname("pixel-tool");
    ArduinoOTA.setPassword(accessPin.c_str());
    ArduinoOTA.onStart([]() {
      setMode(0);
      outputFrame(millis());
    });
    ArduinoOTA.begin();
    MDNS.addService("pixeltool", "tcp", 80);
    MDNS.addServiceTxt("pixeltool", "tcp", "api", "pixeltool-ddp-v1");
    otaStarted = true;
    displayDirty = true;
  }
  if (otaStarted)
    ArduinoOTA.handle();
  if (mode == 4 && running && now - lastStep >= 250) {
    lastStep = now;
    position = position % model.count + 1;
    displayDirty = true;
  }
  if (now - lastFrame >= 100 || lastFrame == 0) {
    lastFrame = now;
    outputFrame(now);
  }
  if (displayDirty && now - lastDraw >= 150) {
    lastDraw = now;
    displayDirty = false;
    draw();
  }
}
