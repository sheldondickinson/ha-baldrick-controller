#pragma once
#include "ModelData.h"
#include <stdint.h>

namespace Pusher {
enum Mode : uint8_t {
  RUNS,
  MARKERS,
  FOCUS,
  LOCATE,
  TEST_RED,
  TEST_GREEN,
  TEST_BLUE
};
struct RGB {
  uint8_t r, g, b;
};
struct State {
  uint8_t model = 0;
  uint8_t mode = RUNS;
  uint16_t run = 0;   // zero-based checkpoint index
  uint16_t node = 1;  // one-based, model-wide node number
  uint8_t level = 32; // maximum channel value, limited to 64
  uint16_t first = 1; // model node corresponding to physical pixel 1
  uint8_t order = 0;  // RGB, RBG, GRB, GBR, BRG, BGR
  bool enabled = false;
};

inline uint16_t runForNode(const Model &m, uint16_t node) {
  uint16_t k = 0;
  while (k + 1 < m.checkpointCount && m.checkpoints[k + 1].node <= node)
    ++k;
  return k;
}

inline RGB tint(uint8_t colour, uint8_t level) {
  const PaletteColour &p = PALETTE[colour];
  return {uint8_t((uint16_t(p.r) * level + 127) / 255),
          uint8_t((uint16_t(p.g) * level + 127) / 255),
          uint8_t((uint16_t(p.b) * level + 127) / 255)};
}

inline bool valid(const State &s) {
  if (s.model >= MODEL_COUNT || s.mode > TEST_BLUE || s.order > 5 ||
      s.level < 1 || s.level > 64)
    return false;
  const Model &m = MODELS[s.model];
  return s.first >= 1 && s.first <= m.count && s.node >= 1 &&
         s.node <= m.count && s.run < m.checkpointCount;
}

inline RGB colourAt(const State &s, uint16_t logicalNode, bool pulse) {
  if (!valid(s) || !s.enabled)
    return {0, 0, 0};
  const Model &m = MODELS[s.model];
  if (logicalNode < s.first || logicalNode > m.count)
    return {0, 0, 0};
  const uint16_t k = runForNode(m, logicalNode);
  const bool marker = m.checkpoints[k].node == logicalNode;
  const uint8_t dim = s.level / 6 ? s.level / 6 : 1;
  if (s.mode == TEST_RED)
    return {s.level, 0, 0};
  if (s.mode == TEST_GREEN)
    return {0, s.level, 0};
  if (s.mode == TEST_BLUE)
    return {0, 0, s.level};
  if (s.mode == MARKERS)
    return marker ? tint(m.checkpoints[k].colour, s.level) : RGB{dim, dim, dim};
  if (s.mode == LOCATE && logicalNode == s.node && pulse)
    return {s.level, s.level, s.level};
  if (s.mode == FOCUS && k == s.run) {
    if (marker && pulse)
      return {s.level, s.level, s.level};
    return tint(m.checkpoints[k].colour, s.level);
  }
  return tint(m.checkpoints[k].colour, marker ? s.level : dim);
}

// Hardware adapter: physical LED 1 maps to the selected first model node.
// Apply both the pusher limit and the main Pixel Tool cap using integers.
inline RGB physicalColour(const State &source, int index, uint8_t cap,
                          bool enabled, bool pulse) {
  if (index < 0 || index >= 1000 || cap == 0)
    return {0, 0, 0};
  State s = source;
  s.enabled = enabled;
  if (s.level > cap)
    s.level = cap;
  return colourAt(s, uint16_t(s.first + index), pulse);
}

inline void makeFrame(const State &s, bool pulse, RGB *frame) {
  for (uint16_t i = 0; i < MAX_PIXELS; ++i) {
    frame[i] = colourAt(s, uint16_t(s.first + i), pulse);
  }
}
} // namespace Pusher
